#!/usr/bin/env python3
"""Main-comparison evaluation (feeds Tables 4/5/8 and Fig. 2(a)/2(b)).

For every instance and every evaluation seed, runs GS-MADE and every
baseline in gsmade.baselines.BASELINES once, pools every method's front
for that (instance, seed) into a shared hypervolume reference point and
IGD reference set (Section 6.3's construction), scores each method
against them, and appends one row per (instance, method, seed) to
results/raw_results.csv.

This is real, runnable code, not a results table: by default it runs a
small, fast "smoke" configuration (few instances, few seeds, small DE/PPO
budgets) so you can sanity-check the whole pipeline in minutes. Scale it
up to the paper's actual protocol (94 instances x 11 methods x 30 seeds,
pop_size ~70, thousands of evaluations per run) with --full, which will
take substantially longer and is intended for a real machine, not a
laptop smoke test. Whatever you get out of a --full run reflects this
repository's implementation, run on your own data/seeds/hardware -- it
is not expected to reproduce the paper's published numbers exactly (see
README "What this is / is not").
"""
from __future__ import annotations

import argparse
import glob
import json
import os
import sys
import time

sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import numpy as np
import pandas as pd

from _common import ROOT, load_environment, load_seeds, pretrain_policy, smallest_first  # noqa: E402

from gsmade import metrics
from gsmade.baselines import BASELINES
from gsmade.encoding import chromosome_length
from gsmade.environment import Environment
from gsmade.lshade import LSHADEConfig
from gsmade.scheduler import GSMADE, GSMADEConfig
from gsmade.workflow import Workflow


def run_one_instance(workflow: Workflow, environment: Environment, eval_seeds: list[int],
                      train_seeds: list[int], pop_size: int, max_evals: int,
                      policy_episodes: int, baseline_subset: list[str],
                      fronts_sink: dict | None = None) -> list[dict]:
    """`fronts_sink`, if given, is filled in-place with
    fronts_sink[instance_name][seed][method] = [[m, e, c], ...] for every
    method's full (not just best-makespan) Pareto front -- used only by
    scripts/make_figures.py's Pareto-front scatter, so passing None here
    (the default) skips that bookkeeping entirely."""
    rows = []
    policy = pretrain_policy(workflow, environment, train_seeds, policy_episodes, hidden_dim=16)

    for seed in eval_seeds:
        rng = np.random.default_rng(seed)
        per_method_front: dict[str, list[tuple]] = {}
        per_method_meta: dict[str, dict] = {}

        # GS-MADE itself
        cfg = GSMADEConfig(
            lshade=LSHADEConfig(dim=chromosome_length(workflow), pop_size_init=pop_size,
                                 pop_size_min=max(6, pop_size // 5), max_evals=max_evals),
            seeding_fraction=0.5, elite_fraction=0.2, vns_period=5,
        )
        t0 = time.time()
        gsm = GSMADE(workflow, environment, cfg, policy, np.random.default_rng(seed))
        result = gsm.run()
        per_method_front["GS-MADE"] = result["front"]
        per_method_meta["GS-MADE"] = {"evals_used": result["evals_used"], "wall_s": time.time() - t0}

        for name in baseline_subset:
            module = BASELINES[name]
            t0 = time.time()
            kwargs = {}
            if name in ("PSO", "GWO", "NSGA-II", "IPSO-GWO", "IMOMA", "cold-start L-SHADE"):
                kwargs = dict(pop_size=pop_size, max_evals=max_evals)
            elif name in ("DRLMOTS", "GA-DRL"):
                kwargs = dict(n_episodes=policy_episodes)
            elif name == "PF-MPPO":
                kwargs = dict(n_pretrain=policy_episodes, n_finetune=10, n_front_points=5)
            br = module.run(workflow, environment, np.random.default_rng(seed), **kwargs)
            per_method_front[name] = br.front
            per_method_meta[name] = {"evals_used": br.evals_used, "wall_s": time.time() - t0}

        pooled = [p for front in per_method_front.values() for p in front]
        if not pooled:
            continue
        ref = metrics.reference_point(pooled, percentile=95.0)
        ref_set = metrics.build_igd_reference_set(pooled)

        if fronts_sink is not None:
            fronts_sink.setdefault(workflow.name, {})[str(seed)] = {
                name: [list(p) for p in front] for name, front in per_method_front.items()
            }

        for name, front in per_method_front.items():
            hv = metrics.hypervolume(front, ref) if front else 0.0
            ig = metrics.igd(front, ref_set) if front else float("inf")
            best = min(front, key=lambda p: p[0]) if front else (float("nan"),) * 3
            rows.append({
                "instance": workflow.name, "family": workflow.family, "scale": workflow.num_tasks,
                "method": name, "seed": seed,
                "makespan_s": best[0], "energy_j": best[1], "cost_usd": best[2],
                "hypervolume": hv, "igd": ig, "front_size": len(front),
                **per_method_meta[name],
            })
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--instances-glob", default=os.path.join(ROOT, "data/instances/*/*.json"))
    ap.add_argument("--seeds-file", default=os.path.join(ROOT, "data/seeds/seeds.json"))
    ap.add_argument("--out", default=os.path.join(ROOT, "results/raw_results.csv"))
    ap.add_argument("--full", action="store_true",
                     help="use the paper's full protocol scale (pop_size=70, max_evals=7340, "
                          "all 30 seeds, all baselines, all instances) -- slow")
    ap.add_argument("--n-instances", type=int, default=2, help="ignored with --full")
    ap.add_argument("--n-seeds", type=int, default=2, help="ignored with --full")
    ap.add_argument("--baselines", nargs="*", default=None,
                     help="subset of BASELINES to run; default: all 10 (GS-MADE is always included)")
    ap.add_argument("--fronts-out", default=os.path.join(ROOT, "results/fronts.json"),
                     help="where to dump full per-(instance,seed,method) Pareto fronts, consumed "
                          "by scripts/make_figures.py's Pareto-front scatter; pass '' to skip")
    args = ap.parse_args()

    instance_paths = sorted(glob.glob(args.instances_glob))
    if not instance_paths:
        print("no instances found -- run scripts/generate_instances.py first", file=sys.stderr)
        sys.exit(1)

    seeds = load_seeds(args.seeds_file)
    baseline_subset = args.baselines or list(BASELINES.keys())

    if args.full:
        pop_size, max_evals, policy_episodes = 70, 7340, 400
        eval_seeds = seeds["evaluation"]
        train_seeds = seeds["training"]
    else:
        # deliberately small -- real generated instances are >=100 tasks
        # (scripts/generate_instances.py has no smaller scale), and this
        # default runs 1 GSMADE + up to 10 baselines per instance x seed,
        # so keeping each run's own budget tiny is what keeps the whole
        # "quickstart" a few minutes instead of a few tens of minutes;
        # pass --full for numbers worth actually looking at
        pop_size, max_evals, policy_episodes = 8, 100, 15
        eval_seeds = seeds["evaluation"][: args.n_seeds]
        train_seeds = seeds["training"][: max(1, args.n_seeds)]
        # smallest_first, not a plain sort: see its docstring -- a bare
        # lexicographic sort would silently pick the *largest* generated
        # instances here (e.g. "..._1000_..." sorts before "..._100_...")
        instance_paths = smallest_first(instance_paths)[: args.n_instances]
        print(f"[smoke mode] {len(instance_paths)} instance(s), {len(eval_seeds)} seed(s), "
              f"pop_size={pop_size}, max_evals={max_evals} -- pass --full for the paper's scale")

    environment = load_environment()

    all_rows = []
    all_fronts: dict = {}
    for path in instance_paths:
        wf = Workflow.load(path)
        print(f"=== {wf.name} ({wf.num_tasks} tasks) ===")
        rows = run_one_instance(wf, environment, eval_seeds, train_seeds, pop_size, max_evals,
                                 policy_episodes, baseline_subset, fronts_sink=all_fronts)
        all_rows.extend(rows)

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    df = pd.DataFrame(all_rows)
    df.to_csv(args.out, index=False)
    print(f"\nwrote {args.out} ({len(df)} rows)")

    if args.fronts_out:
        os.makedirs(os.path.dirname(args.fronts_out), exist_ok=True)
        with open(args.fronts_out, "w") as f:
            json.dump(all_fronts, f)
        print(f"wrote {args.fronts_out}")


if __name__ == "__main__":
    main()

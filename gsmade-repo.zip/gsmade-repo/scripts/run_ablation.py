#!/usr/bin/env python3
"""Ablation study (feeds Table 6): A1-A5, toggling exactly the two
GSMADEConfig fields that gsmade/scheduler.py's module docstring maps
each arm to --

  A1 (L-SHADE only, random seeding)      = GSMADE(seeding_fraction=0, vns_period=None)
  A2 (L-SHADE + VNS, random seeding)     = GSMADE(seeding_fraction=0, vns_period=mu)
  A3 (GAT seeding + L-SHADE, no VNS)     = GSMADE(seeding_fraction=beta, vns_period=None)
  A4 (GAT policy only, no search)        = policy.sample() once per preference, no DE/VNS
  A5 (GS-MADE: GAT + L-SHADE + VNS)      = GSMADE(seeding_fraction=beta, vns_period=mu)

A4 has no LSHADE/VNS component at all, so it is built directly from
GATPolicy.sample() calls (one stochastic sample per Dirichlet preference
draw, non-dominated-filtered into a front) rather than going through
GSMADEConfig.

Same honesty note as scripts/run_evaluation.py: this is real, runnable
code. By default it runs a small smoke configuration; pass --full for
the paper's protocol scale. Numbers produced either way are genuinely
computed by this repository's implementation and are not expected to
match Table 6's published values (see README "What this is / is not").
"""
from __future__ import annotations

import argparse
import glob
import os
import sys
import time

sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import numpy as np
import pandas as pd

from _common import ROOT, load_environment, load_seeds, pretrain_policy, smallest_first  # noqa: E402

from gsmade import encoding, metrics, objectives
from gsmade.encoding import chromosome_length
from gsmade.environment import Environment
from gsmade.gat_policy import GATPolicy
from gsmade.lshade import LSHADEConfig
from gsmade.scheduler import GSMADE, GSMADEConfig
from gsmade.workflow import Workflow

ARM_NAMES = ["A1", "A2", "A3", "A4", "A5"]


def _run_gsmade_arm(workflow: Workflow, environment: Environment, policy: GATPolicy | None,
                     seed: int, pop_size: int, max_evals: int, seeding_fraction: float,
                     vns_period: int | None) -> tuple[list[tuple], dict]:
    cfg = GSMADEConfig(
        lshade=LSHADEConfig(dim=chromosome_length(workflow), pop_size_init=pop_size,
                             pop_size_min=max(6, pop_size // 5), max_evals=max_evals),
        seeding_fraction=seeding_fraction, elite_fraction=0.2, vns_period=vns_period,
    )
    t0 = time.time()
    gsm = GSMADE(workflow, environment, cfg, policy, np.random.default_rng(seed))
    result = gsm.run()
    meta = {"evals_used": result["evals_used"], "wall_s": time.time() - t0}
    return result["front"], meta


def _run_policy_only_arm(workflow: Workflow, environment: Environment, policy: GATPolicy,
                          seed: int, n_preference_samples: int) -> tuple[list[tuple], dict]:
    """A4: no DE, no VNS -- just `n_preference_samples` stochastic policy
    samples across distinct Dirichlet draws, non-dominated-filtered."""
    rng = np.random.default_rng(seed)
    t0 = time.time()
    points = []
    for _ in range(n_preference_samples):
        pref = rng.dirichlet(np.ones(3))
        sample = policy.sample(workflow, pref, deterministic=False)
        order, assignment = encoding.decode(workflow, sample.genes, environment.num_nodes)
        obj = objectives.simulate(workflow, environment, order, assignment).objective_vector
        points.append(obj)
    front = metrics.pareto_front(points)
    meta = {"evals_used": n_preference_samples, "wall_s": time.time() - t0}
    return front, meta


def run_one_instance(workflow: Workflow, environment: Environment, eval_seeds: list[int],
                      train_seeds: list[int], pop_size: int, max_evals: int,
                      policy_episodes: int, n_preference_samples: int,
                      vns_mu: int, beta: float) -> list[dict]:
    rows = []
    policy = pretrain_policy(workflow, environment, train_seeds, policy_episodes, hidden_dim=16)

    for seed in eval_seeds:
        per_arm_front: dict[str, list[tuple]] = {}
        per_arm_meta: dict[str, dict] = {}

        per_arm_front["A1"], per_arm_meta["A1"] = _run_gsmade_arm(
            workflow, environment, policy, seed, pop_size, max_evals,
            seeding_fraction=0.0, vns_period=None)
        per_arm_front["A2"], per_arm_meta["A2"] = _run_gsmade_arm(
            workflow, environment, policy, seed, pop_size, max_evals,
            seeding_fraction=0.0, vns_period=vns_mu)
        per_arm_front["A3"], per_arm_meta["A3"] = _run_gsmade_arm(
            workflow, environment, policy, seed, pop_size, max_evals,
            seeding_fraction=beta, vns_period=None)
        per_arm_front["A4"], per_arm_meta["A4"] = _run_policy_only_arm(
            workflow, environment, policy, seed, n_preference_samples)
        per_arm_front["A5"], per_arm_meta["A5"] = _run_gsmade_arm(
            workflow, environment, policy, seed, pop_size, max_evals,
            seeding_fraction=beta, vns_period=vns_mu)

        pooled = [p for front in per_arm_front.values() for p in front]
        if not pooled:
            continue
        ref = metrics.reference_point(pooled, percentile=95.0)
        ref_set = metrics.build_igd_reference_set(pooled)

        for arm, front in per_arm_front.items():
            hv = metrics.hypervolume(front, ref) if front else 0.0
            ig = metrics.igd(front, ref_set) if front else float("inf")
            best = min(front, key=lambda p: p[0]) if front else (float("nan"),) * 3
            rows.append({
                "instance": workflow.name, "family": workflow.family, "scale": workflow.num_tasks,
                "arm": arm, "seed": seed,
                "makespan_s": best[0], "energy_j": best[1], "cost_usd": best[2],
                "hypervolume": hv, "igd": ig, "front_size": len(front),
                **per_arm_meta[arm],
            })
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--instances-glob", default=os.path.join(ROOT, "data/instances/*/*.json"))
    ap.add_argument("--seeds-file", default=os.path.join(ROOT, "data/seeds/seeds.json"))
    ap.add_argument("--out", default=os.path.join(ROOT, "results/ablation_results.csv"))
    ap.add_argument("--full", action="store_true",
                     help="paper's protocol scale (pop_size=70, max_evals=7340, all 30 seeds) -- slow")
    ap.add_argument("--n-instances", type=int, default=2, help="ignored with --full")
    ap.add_argument("--n-seeds", type=int, default=2, help="ignored with --full")
    ap.add_argument("--vns-mu", type=int, default=5, help="VNS period (generations) for A2/A5")
    ap.add_argument("--beta", type=float, default=0.5, help="GAT seeding fraction for A3/A5")
    args = ap.parse_args()

    instance_paths = sorted(glob.glob(args.instances_glob))
    if not instance_paths:
        print("no instances found -- run scripts/generate_instances.py first", file=sys.stderr)
        sys.exit(1)

    seeds = load_seeds(args.seeds_file)

    if args.full:
        pop_size, max_evals, policy_episodes, n_pref = 70, 7340, 400, 30
        eval_seeds = seeds["evaluation"]
        train_seeds = seeds["training"]
    else:
        # see scripts/run_evaluation.py's matching comment: kept tiny
        # because real instances are >=100 tasks and this default runs
        # all 5 ablation arms per instance x seed
        pop_size, max_evals, policy_episodes, n_pref = 8, 100, 15, 6
        eval_seeds = seeds["evaluation"][: args.n_seeds]
        train_seeds = seeds["training"][: max(1, args.n_seeds)]
        instance_paths = smallest_first(instance_paths)[: args.n_instances]
        print(f"[smoke mode] {len(instance_paths)} instance(s), {len(eval_seeds)} seed(s), "
              f"pop_size={pop_size}, max_evals={max_evals} -- pass --full for the paper's scale")

    environment = load_environment()

    all_rows = []
    for path in instance_paths:
        wf = Workflow.load(path)
        print(f"=== {wf.name} ({wf.num_tasks} tasks) ===")
        rows = run_one_instance(wf, environment, eval_seeds, train_seeds, pop_size, max_evals,
                                 policy_episodes, n_pref, args.vns_mu, args.beta)
        all_rows.extend(rows)

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    df = pd.DataFrame(all_rows)
    df.to_csv(args.out, index=False)
    print(f"\nwrote {args.out} ({len(df)} rows)")


if __name__ == "__main__":
    main()

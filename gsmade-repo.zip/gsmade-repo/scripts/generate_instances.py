#!/usr/bin/env python3
"""Generate the 90 synthetic instances (5 families x 100/500/1000 tasks x
6 seeds, matching the paper's "94 instances from five Pegasus families
and four real WfCommons traces" minus the 4 real traces -- see
scripts/convert_wfcommons_trace.py for those) and write an instance
manifest (data/instances/manifest.json) listing every generated file
with its generator seed and structural stats, so every instance used
anywhere in this repo is traceable back to exactly how it was produced.

Usage:
    python scripts/generate_instances.py [--out data/instances] [--seeds-per-scale 6]
"""
from __future__ import annotations

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from generators import FAMILY_PRESETS, generate  # noqa: E402

SCALES = (100, 500, 1000)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=os.path.join(os.path.dirname(__file__), "..", "data", "instances"))
    ap.add_argument("--seeds-per-scale", type=int, default=6,
                     help="instances generated per (family, scale) pair; "
                          "6 families x 3 scales x this = the synthetic half of the instance pool")
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)

    manifest = []
    base_seed = 1708  # documented, fixed -- see README "Reproducibility"
    counter = 0
    for family in FAMILY_PRESETS:
        fam_dir = os.path.join(args.out, family)
        os.makedirs(fam_dir, exist_ok=True)
        for scale in SCALES:
            for s in range(args.seeds_per_scale):
                seed = base_seed + counter
                counter += 1
                wf = generate(family, scale, seed=seed)
                fname = f"{family}_{scale}_seed{seed}.json"
                path = os.path.join(fam_dir, fname)
                wf.save(path)
                manifest.append({
                    "path": os.path.relpath(path, args.out),
                    "family": family, "scale": scale, "generator_seed": seed,
                    **wf.stats_row(),
                })
                print(f"wrote {path}  {wf.stats_row()}")

    manifest_path = os.path.join(args.out, "manifest.json")
    with open(manifest_path, "w") as f:
        json.dump(manifest, f, indent=2)
    print(f"\nmanifest: {manifest_path} ({len(manifest)} instances)")


if __name__ == "__main__":
    main()

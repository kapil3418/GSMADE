#!/usr/bin/env python3
"""Render results/*.csv into paper-style Markdown tables (results/tables.md),
structurally analogous to Tables 4-8 of the paper.

Honesty note, read before trusting a number out of this script:
  - Every number here is computed from whatever results/*.csv files are
    present on disk, which in turn come from whatever scale you ran
    scripts/run_evaluation.py / run_ablation.py / run_transfer.py at. A
    smoke-mode run (the default) produces a thin, noisy table from 1-2
    instances and 1-2 seeds -- enough to see the table render correctly,
    not enough to mean anything statistically. Use --full on the
    upstream scripts first if you want a table whose numbers are worth
    looking at.
  - These tables are NOT expected to match the paper's published Tables
    4-8 -- different (synthetic) instances, different random seeds,
    different hardware. They are the same *kind* of table, built the
    same way, from this repository's own runs.
  - Table 9 (sim-to-real degradation on a physical five-node fog
    testbed) is intentionally not produced by this script: it requires
    an actual hardware deployment this repository has no access to.
    Fabricating plausible-looking drift numbers would be scientific
    fraud, so make_tables.py prints a note instead of a table for it.
"""
from __future__ import annotations

import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import numpy as np
import pandas as pd

from _common import ROOT  # noqa: E402

from gsmade import metrics  # noqa: E402


def _fmt(x: float, nd: int = 3) -> str:
    if pd.isna(x) or x in (float("inf"), float("-inf")):
        return "–"
    return f"{x:.{nd}f}"


def table4_objectives(raw: pd.DataFrame) -> str:
    """Makespan/energy/cost per family, mean over seeds, at the largest
    scale available per family -- matches Table 4's shape (one row per
    method, one [MS, EN, CO] triple of columns per family)."""
    largest = raw.groupby("family")["scale"].max()
    rows = raw[raw.apply(lambda r: r["scale"] == largest[r["family"]], axis=1)]
    agg = rows.groupby(["method", "family"])[["makespan_s", "energy_j", "cost_usd"]].mean()

    families = sorted(rows["family"].unique())
    methods = sorted(rows["method"].unique(), key=lambda m: (m != "GS-MADE", m))
    header = "| Method | " + " | ".join(f"{fam} MS/EN/CO" for fam in families) + " |"
    sep = "|---" * (len(families) + 1) + "|"
    lines = [header, sep]
    for m in methods:
        cells = []
        for fam in families:
            if (m, fam) in agg.index:
                ms, en, co = agg.loc[(m, fam)]
                cells.append(f"{_fmt(ms, 1)} / {_fmt(en / 1000.0, 2)} / {_fmt(co, 2)}")
            else:
                cells.append("–")
        lines.append(f"| {m} | " + " | ".join(cells) + " |")
    note = ("\n*MS = makespan (s), EN = energy (kJ), CO = cost ($); mean over available seeds "
            f"at the largest generated scale per family (see `scale` column). n_seeds actually "
            f"run: {raw['seed'].nunique()}.*")
    return "\n".join(lines) + note


def table5_quality(raw: pd.DataFrame) -> str:
    """Hypervolume / IGD per family, mean over seeds, plus evaluations-
    to-target and speed-up relative to cold-start L-SHADE -- matches
    Table 5's shape. 'Evaluations to target' here is simply mean
    evals_used (no fixed target hypervolume is defined in this repo's
    config), so speed-up is evals_used(L-SHADE-like baseline) /
    evals_used(method); treat it as a rough proxy, not Table 5's exact
    quantity."""
    families = sorted(raw["family"].unique())
    methods = sorted(raw["method"].unique(), key=lambda m: (m != "GS-MADE", m))
    agg_hv = raw.groupby(["method", "family"])["hypervolume"].mean()
    agg_igd = raw.groupby(["method", "family"])["igd"].mean()
    agg_evals = raw.groupby("method")["evals_used"].mean()

    baseline_name = "cold-start L-SHADE" if "cold-start L-SHADE" in agg_evals.index else None
    baseline_evals = agg_evals.get(baseline_name) if baseline_name else None

    header = "| Method | " + " | ".join(f"{fam} HV/IGD" for fam in families) + " | Evals used | Speed-up |"
    sep = "|---" * (len(families) + 3) + "|"
    lines = [header, sep]
    for m in methods:
        cells = []
        for fam in families:
            hv = agg_hv.get((m, fam), float("nan"))
            ig = agg_igd.get((m, fam), float("nan"))
            cells.append(f"{_fmt(hv, 4)} / {_fmt(ig, 2)}")
        evals = agg_evals.get(m, float("nan"))
        speedup = (baseline_evals / evals) if (baseline_evals and evals) else float("nan")
        lines.append(f"| {m} | " + " | ".join(cells) + f" | {_fmt(evals, 0)} | {_fmt(speedup, 2)}x |")
    return "\n".join(lines)


def table6_ablation(ablation: pd.DataFrame) -> str:
    """Mean HV/IGD/evals/front_size per arm -- matches Table 6's shape
    for arms A1-A5 (this repo does not implement the C1/C2 transplant-
    onto-baselines arms -- see README "What this is / is not")."""
    agg = ablation.groupby("arm")[["hypervolume", "igd", "evals_used", "front_size"]].mean()
    arm_labels = {
        "A1": "L-SHADE only (random seeding)",
        "A2": "L-SHADE + VNS (random seeding)",
        "A3": "GAT seeding + L-SHADE (no VNS)",
        "A4": "GAT policy only (no search)",
        "A5": "GS-MADE (GAT + L-SHADE + VNS)",
    }
    lines = ["| Arm | Configuration | HV | IGD | Evals used | Front size |", "|---|---|---|---|---|---|"]
    for arm in ["A1", "A2", "A3", "A4", "A5"]:
        if arm not in agg.index:
            continue
        hv, ig, ev, fs = agg.loc[arm]
        lines.append(f"| {arm} | {arm_labels[arm]} | {_fmt(hv, 4)} | {_fmt(ig, 2)} | "
                      f"{_fmt(ev, 0)} | {_fmt(fs, 1)} |")
    lines.append("\n*C1/C2 (transplanting the frozen policy onto the two strongest population "
                  "baselines) are not implemented in this repository.*")
    return "\n".join(lines)


def table7_transfer(transfer: pd.DataFrame) -> str:
    """Per-family hypervolume under the transferred policy for each
    protocol, plus the gap to in-family -- matches Table 7's shape.
    Only the 'transferred_policy' variant is used here (see
    scripts/run_transfer.py's module docstring for why 'no_policy' is
    the more informative column for judging transfer *by itself*, kept
    in the raw CSV but not in this table)."""
    sub = transfer[transfer["variant"] == "transferred_policy"]
    agg = sub.groupby(["protocol", "family"])["hypervolume"].mean().unstack("protocol")
    lines = ["| Family | " + " | ".join(agg.columns) + " | Gap in-family->lowo (%) |",
             "|---" * (len(agg.columns) + 2) + "|"]
    for fam, row in agg.iterrows():
        gap = float("nan")
        if "in-family" in row and "lowo" in row and row.get("in-family", 0):
            gap = 100.0 * (row["in-family"] - row["lowo"]) / row["in-family"]
        cells = " | ".join(_fmt(row.get(p, float("nan")), 4) for p in agg.columns)
        lines.append(f"| {fam} | {cells} | {_fmt(gap, 2)} |")
    return "\n".join(lines)


def table8_wilcoxon(raw: pd.DataFrame) -> str:
    """Pairwise Wilcoxon signed-rank test (GS-MADE vs every baseline) on
    per-instance mean hypervolume -- matches Table 8's shape. Needs >=6
    paired (instance, baseline) observations for scipy's exact test to
    run meaningfully; with fewer, scipy itself raises or the result
    carries no real power, so this function reports what it can and
    says so rather than padding in a fake p-value."""
    per_instance = raw.groupby(["instance", "method"])["hypervolume"].mean().unstack("method")
    if "GS-MADE" not in per_instance.columns:
        return "*No GS-MADE rows found -- cannot build Table 8.*"
    gsmade = per_instance["GS-MADE"]
    n_instances = len(per_instance)
    lines = ["| Baseline | Mean HV gain (%) | Wins / instances | Wilcoxon p |", "|---|---|---|---|"]
    for method in per_instance.columns:
        if method == "GS-MADE":
            continue
        other = per_instance[method]
        valid = gsmade.notna() & other.notna()
        wins = int((gsmade[valid] > other[valid]).sum())
        gain = float(100.0 * ((gsmade[valid] - other[valid]) / other[valid].replace(0, np.nan)).mean())
        if valid.sum() >= 6 and not np.allclose(gsmade[valid], other[valid]):
            try:
                _, p = metrics.wilcoxon_signed_rank(gsmade[valid].to_numpy(), other[valid].to_numpy())
                p_str = f"{p:.3g}"
            except Exception as e:  # scipy raises on ties/degenerate input at small n
                p_str = f"n/a ({e})"
        else:
            p_str = f"n/a (only {int(valid.sum())} instances; need >= 6)"
        lines.append(f"| {method} | {_fmt(gain, 2)} | {wins} / {int(valid.sum())} | {p_str} |")
    lines.append(f"\n*Computed over {n_instances} instance(s) actually run. The paper's Table 8 "
                  "uses 94 instances and Holm-corrected p-values across all 11 baselines; this "
                  "table is the same procedure applied to whatever `results/raw_results.csv` "
                  "actually contains, with no Holm correction applied below 6 instances.*")
    return "\n".join(lines)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw", default=os.path.join(ROOT, "results/raw_results.csv"))
    ap.add_argument("--ablation", default=os.path.join(ROOT, "results/ablation_results.csv"))
    ap.add_argument("--transfer", default=os.path.join(ROOT, "results/transfer_results.csv"))
    ap.add_argument("--out", default=os.path.join(ROOT, "results/tables.md"))
    args = ap.parse_args()

    sections = ["# Tables\n\nGenerated by `scripts/make_tables.py` from this repository's own "
                "runs. Read the module docstring (`python -c \"import make_tables\"` won't show "
                "it; open the file) before citing any number below -- see "
                "\"What this is / is not\" in the README.\n"]

    if os.path.exists(args.raw):
        raw = pd.read_csv(args.raw)
        sections.append("## Table 4 -- objectives by family (makespan/energy/cost)\n\n"
                         + table4_objectives(raw))
        sections.append("## Table 5 -- Pareto quality by family (hypervolume/IGD)\n\n"
                         + table5_quality(raw))
        sections.append("## Table 8 -- GS-MADE vs. each baseline (Wilcoxon signed-rank)\n\n"
                         + table8_wilcoxon(raw))
    else:
        sections.append(f"## Tables 4, 5, 8\n\n*{args.raw} not found -- run "
                         "`scripts/run_evaluation.py` first.*")

    if os.path.exists(args.ablation):
        ablation = pd.read_csv(args.ablation)
        sections.append("## Table 6 -- ablation (arms A1-A5)\n\n" + table6_ablation(ablation))
    else:
        sections.append(f"## Table 6\n\n*{args.ablation} not found -- run "
                         "`scripts/run_ablation.py` first.*")

    if os.path.exists(args.transfer):
        transfer = pd.read_csv(args.transfer)
        if len(transfer):
            sections.append("## Table 7 -- generalization (in-family / LOWO / cross-scale)\n\n"
                             + table7_transfer(transfer))
        else:
            sections.append("## Table 7\n\n*results/transfer_results.csv is empty -- every "
                             "protocol was skipped (see scripts/run_transfer.py's console "
                             "output for why; usually too few instances per family).*")
    else:
        sections.append(f"## Table 7\n\n*{args.transfer} not found -- run "
                         "`scripts/run_transfer.py` first.*")

    sections.append("## Table 9 -- sim-to-real degradation\n\n*Not produced by this repository: "
                     "it reports drift measured on an actual five-node physical fog testbed "
                     "(Section 6.11 of the paper), which this codebase has no access to. "
                     "Fabricating substitute numbers here would misrepresent hardware results "
                     "that were never collected, so this table is intentionally left out rather "
                     "than filled in.*")

    out_text = "\n\n".join(sections) + "\n"
    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out, "w") as f:
        f.write(out_text)
    print(f"wrote {args.out}")


if __name__ == "__main__":
    main()

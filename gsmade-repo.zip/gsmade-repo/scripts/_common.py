"""Small helpers shared by scripts/run_evaluation.py, run_ablation.py and
run_transfer.py, so the three experiment drivers agree on exactly how
seeds are loaded and how the GAT policy is pretrained for a given
workflow -- factored out here rather than copy-pasted three times.
"""
from __future__ import annotations

import json
import os

import numpy as np

from gsmade.environment import Environment
from gsmade.gat_policy import GATPolicy, ReinforceTrainer
from gsmade.workflow import Workflow

ROOT = os.path.join(os.path.dirname(__file__), "..")


def load_seeds(path: str) -> dict:
    with open(path) as f:
        return json.load(f)


def smallest_first(paths: list[str]) -> list[str]:
    """Sort instance file paths by file size ascending, a cheap and
    reliable proxy for task count (smaller workflow -> smaller JSON).

    This matters because a plain `sorted(glob(...))` sorts
    lexicographically, and "...CyberShake_1000_seed....json" sorts
    *before* "...CyberShake_100_seed....json" (the character after "100"
    is "_", which is greater than "0" in ASCII) -- so naively taking the
    first --n-instances of a lexicographic sort in smoke mode silently
    picks the *largest* generated instances, not the smallest, making a
    "quick smoke test" anything but quick. Every scripts/run_*.py uses
    this instead of a bare sort whenever it is about to slice a prefix
    of the instance list for a fast default run."""
    return sorted(paths, key=lambda p: os.path.getsize(p))


def load_environment(path: str | None = None) -> Environment:
    return Environment.from_config(path or os.path.join(ROOT, "configs", "three_tier.yaml"))


def pretrain_policy(workflow: Workflow, environment: Environment, train_seeds: list[int],
                     n_episodes: int, hidden_dim: int = 16) -> GATPolicy:
    """Train one GAT policy for `workflow` via REINFORCE over `n_episodes`
    Dirichlet-preference episodes, using only `train_seeds` (disjoint from
    every evaluation seed -- see data/seeds/README.md / generate_seeds.py).
    Every script that needs a trained policy for a workflow calls this the
    same way, so A3/A4/A5's seeding policy is always the same artifact."""
    return pretrain_policy_multi([workflow], environment, train_seeds, n_episodes, hidden_dim)


def pretrain_policy_multi(workflows: list[Workflow], environment: Environment,
                           train_seeds: list[int], n_episodes: int,
                           hidden_dim: int = 16) -> GATPolicy:
    """Same as `pretrain_policy`, but each episode draws a fresh random
    workflow from `workflows` (in addition to a fresh Dirichlet
    preference), so the resulting policy is not specialized to any single
    instance. The 2-layer GAT in gsmade/gat_policy.py embeds nodes from
    local structure only and has no instance-size-dependent parameters,
    so it is architecturally able to run on a workflow it never saw during
    training -- this is what scripts/run_transfer.py's in-family / LOWO /
    cross-scale / zero-shot protocols actually probe: does that
    architectural generalization translate into a useful seeding
    distribution on held-out instances, families or scales."""
    policy = GATPolicy(hidden_dim=hidden_dim, seed=train_seeds[0])
    trainer = ReinforceTrainer(policy)
    rng = np.random.default_rng(train_seeds[0])
    for _ in range(n_episodes):
        wf = workflows[int(rng.integers(0, len(workflows)))]
        pref = rng.dirichlet(np.ones(3))
        trainer.step(wf, environment, pref, environment.num_nodes)
    return policy

#!/usr/bin/env python3
"""Convert a WfCommons-format workflow trace JSON (the schema used by the
WfCommons Pegasus workflow execution instances, reference [24], and by
the `wfcommons` Python package) into this repo's Workflow JSON format.

This repo does not ship real trace files -- the four real-trace families
the paper evaluates zero-shot on (1000Genome, Cycles, SoyKB, SRA Search)
are WfCommons' own recorded executions, released under their own
permanent identifier (reference [24]) and not redistributed here.
To use them:

    pip install wfcommons   # or download the .json trace directly from
                             # https://github.com/wfcommons/pegasus-instances
                             # (or the Zenodo snapshot of reference [24])
    python scripts/convert_wfcommons_trace.py \
        --in path/to/1000genome-chameleon-2ch-100k-001.json \
        --family 1000Genome --out data/instances/1000Genome/

Expected input schema (WfCommons JSON format, 1.x): a top-level
"workflow" (or "specification", in some 1.x revisions) object with a
"tasks" list, each task giving an id/name, a runtime, and either
explicit "parents"/"children" ids or "inputFiles"/"outputFiles" through
which the DAG is inferred via shared file ids; and a "files" (or
per-task "files") list giving each file's size. Both task-linkage
conventions are handled below; if a real file uses a field name this
script doesn't recognize, the error message names exactly which key
lookup failed so the mapping is a one-line fix.
"""
from __future__ import annotations

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import networkx as nx

from gsmade.workflow import Task, Workflow

RUNTIME_KEYS = ("runtimeInSeconds", "runtime", "runtimeSeconds")
SIZE_KEYS = ("sizeInBytes", "size", "fileSize")
MIPS_REFERENCE = 1000.0  # convert a wall-clock runtime (s) on a nominal
                          # 1000-MIPS reference node into a workload in MI,
                          # consistent with every synthetic instance's units


def _first(d: dict, keys: tuple, default=None):
    for k in keys:
        if k in d:
            return d[k]
    return default


def _task_block(raw: dict) -> dict:
    return raw.get("workflow") or raw.get("specification") or raw


def convert(raw: dict, family: str, name: str) -> Workflow:
    block = _task_block(raw)
    raw_tasks = block.get("tasks")
    if raw_tasks is None:
        raise KeyError("could not find a 'tasks' list under raw['workflow'] or "
                        "raw['specification'] or raw itself -- check the trace's schema version")

    file_to_producer: dict[str, str] = {}
    file_size: dict[str, float] = {}
    for raw_file in block.get("files", []):
        fid = raw_file.get("id") or raw_file.get("name")
        if fid is not None:
            file_size[fid] = float(_first(raw_file, SIZE_KEYS, 0.0))

    g = nx.DiGraph()
    tasks: dict[int, Task] = {}
    name_to_id: dict[str, int] = {}
    for i, rt in enumerate(raw_tasks):
        tid = i
        tname = rt.get("name") or rt.get("id") or f"task{i}"
        name_to_id[rt.get("id", tname)] = tid
        name_to_id[tname] = tid
        runtime_s = float(_first(rt, RUNTIME_KEYS, 1.0))
        workload_mi = runtime_s * MIPS_REFERENCE
        g.add_node(tid)
        tasks[tid] = Task(tid, tname, workload_mi=workload_mi)
        for of in rt.get("outputFiles", rt.get("files", {}).get("output", []) if isinstance(rt.get("files"), dict) else []):
            fid = of if isinstance(of, str) else of.get("id") or of.get("name")
            if fid is not None:
                file_to_producer[fid] = tid

    # pass 2: edges, either from explicit parents/children or inferred from
    # shared input/output file ids
    for rt in raw_tasks:
        tname = rt.get("name") or rt.get("id")
        tid = name_to_id[rt.get("id", tname)]
        explicit_parents = rt.get("parents")
        if explicit_parents:
            for p in explicit_parents:
                pid = name_to_id.get(p)
                if pid is not None:
                    g.add_edge(pid, tid, data_mb=1.0)
            continue
        input_files = rt.get("inputFiles", rt.get("files", {}).get("input", []) if isinstance(rt.get("files"), dict) else [])
        for inf in input_files:
            fid = inf if isinstance(inf, str) else inf.get("id") or inf.get("name")
            if fid in file_to_producer:
                pid = file_to_producer[fid]
                data_mb = file_size.get(fid, 1_000_000.0) / 1e6
                if pid != tid:
                    g.add_edge(pid, tid, data_mb=data_mb)

    for tid in list(g.nodes):
        if g.in_degree(tid) == 0 and g.out_degree(tid) == 0 and len(g.nodes) > 1:
            continue  # isolated task with no recorded data dependency -- left as a root

    if not nx.is_directed_acyclic_graph(g):
        raise ValueError("converted graph is not a DAG -- the trace's parent/child or "
                          "file-sharing fields were likely misread; check RUNTIME_KEYS/edge inference above")

    return Workflow(name=name, family=family, graph=g, tasks=tasks, deadline_factor=1.5)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="inp", required=True)
    ap.add_argument("--family", required=True, choices=["1000Genome", "Cycles", "SoyKB", "SRA_Search"])
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    with open(args.inp) as f:
        raw = json.load(f)
    name = os.path.splitext(os.path.basename(args.inp))[0]
    wf = convert(raw, args.family, name)
    os.makedirs(args.out, exist_ok=True)
    out_path = os.path.join(args.out, f"{name}.json")
    wf.save(out_path)
    print(f"wrote {out_path}  {wf.stats_row()}")


if __name__ == "__main__":
    main()

"""scripts/convert_wfcommons_trace.py against two small hand-built
fixtures -- NOT real WfCommons data (this repo ships none, see
data/instances/README.md), just schema-shaped test input covering both
linkage conventions the converter documents handling: explicit
parents/children ids, and file-sharing-inferred edges."""
from __future__ import annotations

import pytest

from convert_wfcommons_trace import convert


def test_convert_with_explicit_parents_field():
    raw = {
        "workflow": {
            "tasks": [
                {"id": "A", "name": "A", "runtime": 2.0},
                {"id": "B", "name": "B", "runtime": 3.0, "parents": ["A"]},
                {"id": "C", "name": "C", "runtime": 1.0, "parents": ["A"]},
                {"id": "D", "name": "D", "runtime": 4.0, "parents": ["B", "C"]},
            ],
            "files": [],
        }
    }
    wf = convert(raw, family="1000Genome", name="fixture_explicit")
    assert wf.num_tasks == 4
    assert wf.num_edges == 4
    ids = {t.name: tid for tid, t in wf.tasks.items()}
    assert set(wf.predecessors(ids["D"])) == {ids["B"], ids["C"]}
    assert wf.predecessors(ids["A"]) == []


def test_convert_infers_edges_from_shared_input_output_files():
    raw = {
        "workflow": {
            "tasks": [
                {"id": "A", "name": "A", "runtime": 2.0, "outputFiles": ["f1"]},
                {"id": "B", "name": "B", "runtime": 3.0, "inputFiles": ["f1"], "outputFiles": ["f2"]},
                {"id": "C", "name": "C", "runtime": 1.0, "inputFiles": ["f2"]},
            ],
            "files": [
                {"id": "f1", "sizeInBytes": 2_000_000},
                {"id": "f2", "sizeInBytes": 500_000},
            ],
        }
    }
    wf = convert(raw, family="SoyKB", name="fixture_inferred")
    assert wf.num_tasks == 3
    ids = {t.name: tid for tid, t in wf.tasks.items()}
    assert wf.predecessors(ids["B"]) == [ids["A"]]
    assert wf.predecessors(ids["C"]) == [ids["B"]]
    # f1 is 2MB -> edge A->B should carry 2.0 MB
    assert wf.edge_data_mb(ids["A"], ids["B"]) == pytest.approx(2.0)


def test_convert_raises_a_clear_error_when_tasks_list_is_missing():
    with pytest.raises(KeyError):
        convert({"not_a_workflow": {}}, family="Cycles", name="bad_fixture")


def test_convert_rejects_a_trace_whose_inferred_graph_has_a_cycle():
    # f1 depends on f2 and f2 depends on f1 -> not a DAG
    raw = {
        "workflow": {
            "tasks": [
                {"id": "A", "name": "A", "runtime": 1.0, "inputFiles": ["f2"], "outputFiles": ["f1"]},
                {"id": "B", "name": "B", "runtime": 1.0, "inputFiles": ["f1"], "outputFiles": ["f2"]},
            ],
            "files": [{"id": "f1", "sizeInBytes": 1000}, {"id": "f2", "sizeInBytes": 1000}],
        }
    }
    with pytest.raises(ValueError):
        convert(raw, family="Cycles", name="cyclic_fixture")


def test_convert_handles_specification_key_variant():
    raw = {
        "specification": {
            "tasks": [
                {"id": "A", "name": "A", "runtime": 1.0},
                {"id": "B", "name": "B", "runtime": 1.0, "parents": ["A"]},
            ],
        }
    }
    wf = convert(raw, family="SRA_Search", name="fixture_spec_key")
    assert wf.num_tasks == 2
    assert wf.num_edges == 1

"""Shared fixtures: one small, hand-built toy workflow and the real
three-tier environment (loaded from configs/three_tier.yaml, same as
every script in this repo -- no separate "test" environment config, so
a test failure here would also be a real-run failure).

The toy workflow is deliberately tiny (8 tasks) so every test in this
suite runs in well under a second; the generators/ and baselines/
integration tests below are the ones that actually exercise realistic
instance sizes, at a scale still small enough for a laptop CPU.
"""
from __future__ import annotations

import os
import sys

import networkx as nx
import numpy as np
import pytest

ROOT = os.path.join(os.path.dirname(__file__), "..")
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "scripts"))

from gsmade.environment import Environment  # noqa: E402
from gsmade.workflow import Task, Workflow  # noqa: E402


def build_toy_workflow(name: str = "toy_8") -> Workflow:
    """A small diamond-of-diamonds DAG: 0 -> {1,2} -> {3,4} -> {5,6} -> 7,
    with a couple of extra cross edges so it is not a trivial chain."""
    g = nx.DiGraph()
    edges = [(0, 1), (0, 2), (1, 3), (2, 3), (1, 4), (2, 5),
             (3, 6), (4, 6), (5, 6), (3, 7), (6, 7)]
    g.add_edges_from(edges)
    rng = np.random.default_rng(42)
    tasks = {
        tid: Task(tid, f"t{tid}", workload_mi=float(rng.uniform(50, 400)))
        for tid in g.nodes
    }
    for u, v in g.edges:
        g.edges[u, v]["data_mb"] = float(rng.uniform(1, 20))
    return Workflow(name=name, family="toy", graph=g, tasks=tasks, deadline_factor=1.8)


@pytest.fixture
def toy_workflow() -> Workflow:
    return build_toy_workflow()


@pytest.fixture(scope="session")
def environment() -> Environment:
    return Environment.from_config(os.path.join(ROOT, "configs", "three_tier.yaml"))

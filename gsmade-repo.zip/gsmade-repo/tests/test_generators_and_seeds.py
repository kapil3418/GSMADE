"""Synthetic instance generators (scripts/generators.py) and the
evaluation/training seed-block generator (scripts/generate_seeds.py) --
both imported directly from scripts/ the same way scripts/*.py import
each other (see tests/conftest.py's sys.path setup)."""
from __future__ import annotations

import networkx as nx
import numpy as np
import pytest

from generate_seeds import build_evaluation_seeds, build_training_seeds
from generators import FAMILY_PRESETS, generate


@pytest.mark.parametrize("family", sorted(FAMILY_PRESETS))
@pytest.mark.parametrize("num_tasks", [20, 100])
def test_generated_instance_is_a_connected_dag_of_the_requested_size(family, num_tasks):
    wf = generate(family, num_tasks, seed=123)
    assert wf.num_tasks == num_tasks
    assert nx.is_directed_acyclic_graph(wf.graph)
    assert nx.is_weakly_connected(wf.graph)
    # exactly one source: _level_sizes reserves a single-node root level,
    # and every other level's nodes are guaranteed an incoming edge (the
    # fallback-parent pass in generate()). There is no equivalent
    # guarantee on the *sink* side -- an intermediate-level node can end
    # up with no outgoing edge if no node in the next level happened to
    # pick it as a parent, so multiple sinks are expected, not a bug.
    sources = [n for n in wf.graph.nodes if wf.graph.in_degree(n) == 0]
    assert len(sources) == 1
    root = sources[0]
    # every task must be reachable forward from the single root, and the
    # designated final (single-node) sink level's task must be reachable
    # from every other task -- together these are the meaningful
    # "well-formed DAG" property, independent of how many sinks there are
    reachable_from_root = nx.descendants(wf.graph, root) | {root}
    assert reachable_from_root == set(wf.graph.nodes)
    # the designated final (single-node) sink level's task never appears as
    # a `src_level` in generate(), so it is guaranteed to have no outgoing
    # edges -- it need not be reachable from every other task, though,
    # since only forward-from-root reachability is actually guaranteed.
    designated_sink = max(wf.graph.nodes)  # tasks are added root..levels..sink, in order
    assert wf.graph.out_degree(designated_sink) == 0


def test_generate_is_reproducible_from_the_same_seed():
    wf1 = generate("Montage", 40, seed=7)
    wf2 = generate("Montage", 40, seed=7)
    assert wf1.to_dict() == wf2.to_dict()


def test_generate_rejects_unknown_family():
    with pytest.raises(ValueError):
        generate("NotAFamily", 20, seed=0)


def test_different_families_produce_structurally_distinct_instances():
    # same scale and seed, different family presets -> different depth
    # and/or max-width (the whole point of per-family presets)
    stats = {fam: generate(fam, 60, seed=1).stats_row() for fam in FAMILY_PRESETS}
    shapes = {(s["Depth"], s["Max width"]) for s in stats.values()}
    assert len(shapes) > 1, "all families produced the same structural shape"


def test_evaluation_seeds_match_the_papers_documented_shape():
    seeds = build_evaluation_seeds()
    assert len(seeds) == 30
    assert seeds == sorted(set(seeds))  # strictly increasing, no duplicates
    assert seeds[0] == 11
    assert seeds[1] == 23
    assert seeds[2] == 37
    assert seeds[-1] == 331


def test_training_seeds_are_disjoint_from_evaluation_seeds():
    eval_seeds = build_evaluation_seeds()
    train_seeds = build_training_seeds(200, set(eval_seeds))
    assert len(train_seeds) == 200
    assert set(train_seeds).isdisjoint(eval_seeds)
    assert train_seeds == sorted(set(train_seeds))


def test_seed_generation_is_deterministic():
    assert build_evaluation_seeds() == build_evaluation_seeds()
    ev = set(build_evaluation_seeds())
    assert build_training_seeds(50, ev) == build_training_seeds(50, ev)

"""End-to-end integration: pretrain a policy, run GS-MADE and a few
baselines on the toy workflow, pool fronts, score hypervolume/IGD --
the same pipeline scripts/run_evaluation.py runs at full scale, checked
here at a tiny budget so it runs in seconds as part of the normal test
suite. This is the formal version of the manual smoke test used while
building the repository (run_evaluation.py --n-instances 2 --n-seeds 2)."""
from __future__ import annotations

import numpy as np
import pytest

from gsmade import metrics
from gsmade.baselines import BASELINES
from gsmade.encoding import chromosome_length
from gsmade.lshade import LSHADEConfig
from gsmade.scheduler import GSMADE, GSMADEConfig

import sys, os  # noqa: E402
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "scripts"))
from _common import pretrain_policy  # noqa: E402


def test_full_pipeline_runs_and_produces_sane_comparison_rows(toy_workflow, environment):
    train_seeds = [1001, 1002]
    eval_seeds = [11, 23]
    pop_size, max_evals, policy_episodes = 10, 60, 15

    policy = pretrain_policy(toy_workflow, environment, train_seeds, policy_episodes, hidden_dim=8)

    rows = []
    for seed in eval_seeds:
        per_method_front = {}

        cfg = GSMADEConfig(
            lshade=LSHADEConfig(dim=chromosome_length(toy_workflow), pop_size_init=pop_size,
                                 pop_size_min=5, max_evals=max_evals),
            seeding_fraction=0.5, elite_fraction=0.2, vns_period=4,
        )
        gsm = GSMADE(toy_workflow, environment, cfg, policy, np.random.default_rng(seed))
        per_method_front["GS-MADE"] = gsm.run()["front"]

        for name in ("HEFT", "Min-Min", "PSO", "cold-start L-SHADE"):
            kwargs = {"pop_size": pop_size, "max_evals": max_evals} if name in (
                "PSO", "cold-start L-SHADE") else {}
            br = BASELINES[name].run(toy_workflow, environment, np.random.default_rng(seed), **kwargs)
            per_method_front[name] = br.front

        pooled = [p for front in per_method_front.values() for p in front]
        assert pooled, "no method produced any front at all"
        ref = metrics.reference_point(pooled, percentile=95.0)
        ref_set = metrics.build_igd_reference_set(pooled)

        for name, front in per_method_front.items():
            hv = metrics.hypervolume(front, ref) if front else 0.0
            ig = metrics.igd(front, ref_set) if front else float("inf")
            assert hv >= 0.0
            assert ig >= 0.0
            rows.append({"method": name, "seed": seed, "hypervolume": hv, "igd": ig,
                         "front_size": len(front)})

    assert len(rows) == len(eval_seeds) * 5  # GS-MADE + 4 baselines, per seed

    # sanity: GS-MADE (full search + learned seeding) should not be worse,
    # on *mean* hypervolume over these two seeds, than either unseeded
    # single-point heuristic (HEFT/Min-Min) -- a much weaker bar than the
    # paper's claims, chosen so this test is a real pipeline-integrity
    # check without asserting anything about the paper's specific margins
    import pandas as pd
    df = pd.DataFrame(rows)
    mean_hv = df.groupby("method")["hypervolume"].mean()
    assert mean_hv["GS-MADE"] >= mean_hv["HEFT"]
    assert mean_hv["GS-MADE"] >= mean_hv["Min-Min"]


def test_pipeline_result_rows_never_contain_the_papers_published_numbers_by_construction(toy_workflow, environment):
    """Not a statistical check -- a documentation-as-test reminder that
    this repository computes its own numbers on its own (toy, in this
    test) instances and must never special-case or hardcode a published
    Table 4-9 value anywhere in the pipeline. Grepping the source tree
    for suspicious hardcoded result constants is a better guard than a
    runtime assertion, but this test at least exercises the real call
    path end to end once more under pytest."""
    cfg = GSMADEConfig(
        lshade=LSHADEConfig(dim=chromosome_length(toy_workflow), pop_size_init=8,
                             pop_size_min=4, max_evals=40),
        seeding_fraction=0.0, vns_period=None,
    )
    gsm = GSMADE(toy_workflow, environment, cfg, policy=None, rng=np.random.default_rng(99))
    front = gsm.run()["front"]
    assert len(front) >= 1

"""VNS neighbourhoods (N1-N4) and the shake-then-descend driver: every
move must return a complete, in-range assignment, and local search must
never leave the incumbent worse off than where it started."""
from __future__ import annotations

import numpy as np
import pytest

from gsmade import encoding, objectives
from gsmade.lshade import dominates
from gsmade.vns import n1_move, n2_move, n3_move, n4_move, vns_local_search


def _decoded(toy_workflow, environment, seed):
    rng = np.random.default_rng(seed)
    genes = encoding.random_genes(toy_workflow, rng)
    order, assignment = encoding.decode(toy_workflow, genes, environment.num_nodes)
    result = objectives.simulate(toy_workflow, environment, order, assignment)
    return order, assignment, result, rng


@pytest.mark.parametrize("move_fn", [n1_move, n2_move, n3_move, n4_move])
def test_each_neighborhood_move_returns_a_complete_in_range_assignment(toy_workflow, environment, move_fn):
    order, assignment, result, rng = _decoded(toy_workflow, environment, seed=0)
    new_assignment = move_fn(toy_workflow, environment, order, assignment, result, rng)
    assert set(new_assignment.keys()) == set(toy_workflow.tasks.keys())
    assert all(0 <= nid < environment.num_nodes for nid in new_assignment.values())


def test_n2_move_actually_crosses_a_tier_boundary(toy_workflow, environment):
    order, assignment, result, rng = _decoded(toy_workflow, environment, seed=1)
    new_assignment = n2_move(toy_workflow, environment, order, assignment, result, rng)
    changed = [t for t in assignment if assignment[t] != new_assignment[t]]
    assert len(changed) == 1
    tid = changed[0]
    old_tier = environment.nodes[assignment[tid]].tier
    new_tier = environment.nodes[new_assignment[tid]].tier
    assert old_tier != new_tier


def test_n4_move_colocates_task_with_its_dominant_predecessor(toy_workflow, environment):
    order, assignment, result, rng = _decoded(toy_workflow, environment, seed=2)
    new_assignment = n4_move(toy_workflow, environment, order, assignment, result, rng)
    changed = [t for t in assignment if assignment[t] != new_assignment[t]]
    if not changed:
        pytest.skip("no task with predecessors was selected by this rng draw")
    tid = changed[0]
    preds = toy_workflow.predecessors(tid)
    dominant = max(preds, key=lambda p: toy_workflow.edge_data_mb(p, tid))
    assert new_assignment[tid] == assignment[dominant]


@pytest.mark.parametrize("seed", range(8))
def test_vns_local_search_never_makes_the_incumbent_worse(toy_workflow, environment, seed):
    rng = np.random.default_rng(seed)
    genes = encoding.random_genes(toy_workflow, rng)
    order, assignment = encoding.decode(toy_workflow, genes, environment.num_nodes)
    start_obj = objectives.simulate(toy_workflow, environment, order, assignment).objective_vector

    new_genes, new_obj, calls_used = vns_local_search(toy_workflow, environment, genes, environment.num_nodes,
                                                       rng, k_max=4, trials_per_neighborhood=5)

    # vns_local_search only ever replaces the incumbent with a trial that
    # strictly dominates it, so the result must weakly dominate the start:
    # every objective no worse, and it must match what re-decoding the
    # returned genes actually produces.
    assert all(a <= b for a, b in zip(new_obj, start_obj))
    order2, assignment2 = encoding.decode(toy_workflow, new_genes, environment.num_nodes)
    recomputed = objectives.simulate(toy_workflow, environment, order2, assignment2).objective_vector
    assert recomputed == pytest.approx(new_obj)
    assert calls_used >= 1  # at least the initial incumbent evaluation


def test_vns_local_search_respects_max_calls_budget(toy_workflow, environment):
    rng = np.random.default_rng(5)
    genes = encoding.random_genes(toy_workflow, rng)
    _, _, calls_used = vns_local_search(toy_workflow, environment, genes, environment.num_nodes,
                                         rng, k_max=4, trials_per_neighborhood=8, max_calls=3)
    assert calls_used <= 3 + environment.num_nodes  # may overshoot by one N1 call's internal sweep


def test_vns_local_search_offers_incomparable_neighbors_to_the_archive(toy_workflow, environment):
    from gsmade.lshade import ExternalArchive

    rng = np.random.default_rng(3)
    genes = encoding.random_genes(toy_workflow, rng)
    archive = ExternalArchive()
    vns_local_search(toy_workflow, environment, genes, environment.num_nodes, rng,
                      k_max=4, trials_per_neighborhood=8, archive=archive)
    # not a strict requirement that the archive is non-empty (depends on
    # the random walk), but if it has members they must be real,
    # non-dominated-among-themselves objective vectors
    objs = archive.front()
    for i, a in enumerate(objs):
        for j, b in enumerate(objs):
            if i != j:
                assert not dominates(a, b)

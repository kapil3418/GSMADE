"""Every baseline in gsmade.baselines.BASELINES, run end-to-end on the
toy workflow at a tiny budget -- the same kind of check that was done ad
hoc for each baseline while building this repo, formalized so a future
change can't silently break one baseline without a test noticing."""
from __future__ import annotations

import numpy as np
import pytest

from gsmade.baselines import BASELINES

# mirrors scripts/run_evaluation.py's per-baseline kwarg mapping, at a
# much smaller budget so the whole file runs in seconds, not minutes
_KWARGS = {
    "PSO": dict(pop_size=8, max_evals=30),
    "GWO": dict(pop_size=8, max_evals=30),
    "NSGA-II": dict(pop_size=8, max_evals=30),
    "IPSO-GWO": dict(pop_size=8, max_evals=30),
    "IMOMA": dict(pop_size=8, max_evals=30),
    "cold-start L-SHADE": dict(pop_size=8, max_evals=30),
    "DRLMOTS": dict(n_episodes=8),
    "GA-DRL": dict(n_episodes=8),
    "PF-MPPO": dict(n_pretrain=8, n_finetune=2, n_front_points=3),
}


@pytest.mark.parametrize("name", sorted(BASELINES))
def test_baseline_runs_and_returns_finite_objectives(toy_workflow, environment, name):
    module = BASELINES[name]
    kwargs = _KWARGS.get(name, {})
    result = module.run(toy_workflow, environment, np.random.default_rng(0), **kwargs)

    assert result.name or result.name == ""  # has a name attribute at all
    assert result.evals_used >= 0
    front = result.front
    assert len(front) >= 1, f"{name} returned an empty front"
    for point in front:
        assert len(point) == 3
        assert all(np.isfinite(v) for v in point), f"{name} produced a non-finite objective: {point}"
        assert all(v >= 0 for v in point), f"{name} produced a negative objective: {point}"


def test_heft_and_minmin_report_a_single_point_archive(toy_workflow, environment):
    # paper/README: "HEFT and Min-Min ... report a one-point archive"
    for name in ("HEFT", "Min-Min"):
        result = BASELINES[name].run(toy_workflow, environment, np.random.default_rng(0))
        assert len(result.front) == 1


def test_baselines_are_deterministic_given_the_same_rng_seed(toy_workflow, environment):
    for name in ("PSO", "GWO", "cold-start L-SHADE"):
        kwargs = _KWARGS[name]
        r1 = BASELINES[name].run(toy_workflow, environment, np.random.default_rng(42), **kwargs)
        r2 = BASELINES[name].run(toy_workflow, environment, np.random.default_rng(42), **kwargs)
        assert sorted(r1.front) == sorted(r2.front), f"{name} is not seed-reproducible"

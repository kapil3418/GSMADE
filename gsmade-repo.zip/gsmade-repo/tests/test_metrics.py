"""Multi-objective indicator tests. The hypervolume checks in particular
use an independent Monte-Carlo cross-check rather than more hand-derived
geometry, so a bug in the exact dimension-sweep implementation can't
also be baked into the test's expected value by the same arithmetic
mistake."""
from __future__ import annotations

import numpy as np
import pytest

from gsmade import metrics


def test_hypervolume_single_point_matches_hand_calculation():
    # Minimization hypervolume: the region credited to a point p is the
    # box [p, ref] (from p out to the worse reference corner), not [0, p].
    # One point at (1,1,1) against ref (3,2,1.5): box [1,3]x[1,2]x[1,1.5],
    # volume 2 * 1 * 0.5 = 1.0 -- no sweep logic needed to check this by hand.
    assert metrics.hypervolume([(1.0, 1.0, 1.0)], (3.0, 2.0, 1.5)) == pytest.approx(1.0)


def test_hypervolume_empty_front_is_zero():
    assert metrics.hypervolume([], (1.0, 1.0, 1.0)) == 0.0


def test_hypervolume_matches_monte_carlo_estimate():
    rng = np.random.default_rng(7)
    raw = [tuple(rng.uniform(0.0, 1.0, size=3)) for _ in range(25)]
    front = metrics.pareto_front(raw)
    ref = (1.1, 1.1, 1.1)

    hv_exact = metrics.hypervolume(front, ref)

    n = 300_000
    samples = rng.uniform([0, 0, 0], ref, size=(n, 3))
    box_vol = ref[0] * ref[1] * ref[2]
    dominated = np.zeros(n, dtype=bool)
    for p in front:
        # a sample is "covered" by p if p dominates it or ties it, i.e. the
        # sample lies in the box [p, ref] -- the region hypervolume() credits
        # to p (NOT [0, p]; minimization hypervolume measures how much of
        # the space between the front and the worse reference corner is
        # improved upon, not how much of the space from the origin is used).
        dominated |= np.all(samples >= np.asarray(p), axis=1)
    hv_mc = dominated.mean() * box_vol

    assert hv_exact == pytest.approx(hv_mc, abs=0.015 * box_vol)


def test_hypervolume_monotonic_in_front_size():
    # Adding a new non-dominated point can only raise (or keep equal) HV.
    ref = (1.0, 1.0, 1.0)
    front = [(0.5, 0.5, 0.5)]
    hv1 = metrics.hypervolume(front, ref)
    front2 = front + [(0.2, 0.8, 0.5)]  # non-dominated relative to the first point
    hv2 = metrics.hypervolume(front2, ref)
    assert hv2 >= hv1


def test_pareto_front_removes_dominated_points():
    pts = [(1.0, 1.0, 1.0), (2.0, 2.0, 2.0), (0.5, 3.0, 3.0)]
    front = metrics.pareto_front(pts)
    assert (2.0, 2.0, 2.0) not in front  # dominated by (1,1,1)
    assert (1.0, 1.0, 1.0) in front
    assert (0.5, 3.0, 3.0) in front  # non-dominated (better in dim 0)


def test_igd_zero_when_front_equals_reference():
    ref_set = [(0.0, 0.0, 0.0), (1.0, 0.0, 0.0), (0.0, 1.0, 0.0)]
    assert metrics.igd(ref_set, ref_set) == pytest.approx(0.0)


def test_igd_empty_front_is_infinite_but_empty_reference_is_zero():
    assert metrics.igd([], [(0.0, 0.0, 0.0)]) == float("inf")
    assert metrics.igd([(0.0, 0.0, 0.0)], []) == 0.0


def test_reference_point_is_weakly_worse_than_every_point():
    rng = np.random.default_rng(1)
    pts = [tuple(rng.uniform(0, 1, 3)) for _ in range(20)]
    ref = metrics.reference_point(pts, percentile=95.0)
    arr = np.asarray(pts)
    # the 95th percentile ref should dominate (be weakly worse than) at
    # least 95% of points in every objective, and strictly worse than the
    # per-objective max minus the occasional outlier
    assert all(ref[j] >= np.percentile(arr[:, j], 94.0) for j in range(3))


def test_knee_point_returns_a_front_member():
    front = [(0.0, 1.0, 1.0), (1.0, 0.0, 1.0), (1.0, 1.0, 0.0), (0.4, 0.4, 0.4)]
    knee = metrics.knee_point(front)
    assert knee in front


def test_knee_point_single_point_front():
    assert metrics.knee_point([(1.0, 2.0, 3.0)]) == (1.0, 2.0, 3.0)


def test_nemenyi_critical_difference_known_table_value():
    # Demsar (2006) Table 5(b): q_0.05 for k=5 treatments is 2.728.
    cd = metrics.nemenyi_critical_difference(k=5, n_blocks=10)
    expected = 2.728 * np.sqrt(5 * 6 / (6.0 * 10))
    assert cd == pytest.approx(expected)


def test_nemenyi_rejects_unsupported_alpha():
    with pytest.raises(NotImplementedError):
        metrics.nemenyi_critical_difference(k=5, n_blocks=10, alpha=0.01)


def test_wilcoxon_signed_rank_matches_scipy():
    from scipy import stats
    rng = np.random.default_rng(2)
    a = rng.uniform(0, 1, 12)
    b = a + rng.normal(0.3, 0.05, 12)  # b consistently larger
    stat, p = metrics.wilcoxon_signed_rank(a, b)
    ref_stat, ref_p = stats.wilcoxon(a, b)
    assert stat == pytest.approx(ref_stat)
    assert p == pytest.approx(ref_p)


def test_paired_confidence_interval_contains_the_mean():
    rng = np.random.default_rng(3)
    diffs = rng.normal(0.05, 0.02, 30)
    mean, lo, hi = metrics.paired_confidence_interval(diffs)
    assert lo <= mean <= hi
    assert mean == pytest.approx(diffs.mean())


def test_friedman_test_rejects_equality_when_one_treatment_is_clearly_better():
    rng = np.random.default_rng(4)
    n_blocks = 20
    col_a = rng.uniform(0, 1, n_blocks)
    col_b = rng.uniform(0, 1, n_blocks)
    col_c = col_a + 5.0  # always best -> consistent rank-1 across all blocks
    chi2, p = metrics.friedman_test(np.stack([col_a, col_b, col_c], axis=1))
    assert p < 0.01

"""GS-MADE orchestration, and the exact A1-A5 ablation-arm config mapping
documented in gsmade/scheduler.py's module docstring -- this test is a
regression guard: if someone changes GSMADEConfig's defaults without
updating the docstring (or scripts/run_ablation.py), this fails."""
from __future__ import annotations

import numpy as np
import pytest

from gsmade.encoding import chromosome_length
from gsmade.gat_policy import GATPolicy
from gsmade.lshade import LSHADEConfig
from gsmade.scheduler import GSMADE, GSMADEConfig, build_seed_population


@pytest.fixture
def small_policy(toy_workflow):
    # untrained is fine here -- these tests check that every arm *runs*
    # and returns a sane front, not that the policy has learned anything
    # (gsmade/gat_policy.py's own ReinforceTrainer learning test covers that)
    return GATPolicy(hidden_dim=8, seed=0)


ARM_CONFIGS = {
    "A1": dict(seeding_fraction=0.0, vns_period=None),
    "A2": dict(seeding_fraction=0.0, vns_period=4),
    "A3": dict(seeding_fraction=0.5, vns_period=None),
    "A5": dict(seeding_fraction=0.5, vns_period=4),
}


@pytest.mark.parametrize("arm", sorted(ARM_CONFIGS))
def test_each_ablation_arm_runs_and_returns_a_valid_front(toy_workflow, environment, small_policy, arm):
    params = ARM_CONFIGS[arm]
    cfg = GSMADEConfig(
        lshade=LSHADEConfig(dim=chromosome_length(toy_workflow), pop_size_init=10,
                             pop_size_min=5, max_evals=60),
        elite_fraction=0.2, **params,
    )
    policy = small_policy if params["seeding_fraction"] > 0 else None
    gsm = GSMADE(toy_workflow, environment, cfg, policy, np.random.default_rng(0))
    result = gsm.run()

    assert len(result["front"]) >= 1
    assert result["evals_used"] >= cfg.lshade.max_evals
    assert result["seeding_fraction"] == params["seeding_fraction"]
    assert result["vns_period"] == params["vns_period"]


def test_a4_policy_only_arm_uses_sample_with_no_search(toy_workflow, environment, small_policy):
    """A4 (Table 6): the frozen policy with no DE/VNS at all. GSMADE
    itself doesn't implement this arm (it always runs L-SHADE, per its
    module docstring) -- scripts/run_ablation.py builds A4 directly from
    GATPolicy.sample(), which this test exercises the same way."""
    rng = np.random.default_rng(0)
    pref = rng.dirichlet(np.ones(3))
    sample = small_policy.sample(toy_workflow, pref, deterministic=False)
    assert sample.genes.shape == (2 * toy_workflow.num_tasks,)
    assert np.all((sample.genes >= 0.0) & (sample.genes <= 1.0))


def test_seeding_fraction_zero_does_not_require_a_policy(toy_workflow, environment):
    cfg = GSMADEConfig(
        lshade=LSHADEConfig(dim=chromosome_length(toy_workflow), pop_size_init=8,
                             pop_size_min=4, max_evals=40),
        seeding_fraction=0.0, vns_period=None,
    )
    gsm = GSMADE(toy_workflow, environment, cfg, policy=None, rng=np.random.default_rng(0))
    result = gsm.run()
    assert len(result["front"]) >= 1


def test_seeding_fraction_positive_without_a_policy_raises_or_falls_back(toy_workflow, environment):
    # GSMADE._initial_population returns None if policy is None regardless
    # of seeding_fraction (it never crashes) -- document that behavior.
    cfg = GSMADEConfig(
        lshade=LSHADEConfig(dim=chromosome_length(toy_workflow), pop_size_init=8,
                             pop_size_min=4, max_evals=40),
        seeding_fraction=0.5, vns_period=None,
    )
    gsm = GSMADE(toy_workflow, environment, cfg, policy=None, rng=np.random.default_rng(0))
    assert gsm._initial_population() is None
    result = gsm.run()  # should still run fine with a random initial population
    assert len(result["front"]) >= 1


def test_build_seed_population_shape(toy_workflow, environment, small_policy):
    rng = np.random.default_rng(0)
    seeds = build_seed_population(small_policy, toy_workflow, environment.num_nodes,
                                   n_samples=6, rng=rng)
    assert seeds.shape == (6, 2 * toy_workflow.num_tasks)

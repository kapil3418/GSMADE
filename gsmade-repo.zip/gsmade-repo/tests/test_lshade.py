"""Multi-objective L-SHADE: dominance bookkeeping (non-dominated sort,
crowding distance, the external archive) and an end-to-end run on the
toy workflow."""
from __future__ import annotations

import numpy as np
import pytest

from gsmade import encoding, objectives
from gsmade.lshade import (
    ExternalArchive, Individual, LSHADE, LSHADEConfig, crowding_distance,
    dominates, environmental_selection, non_dominated_sort,
)


def test_dominates_is_a_strict_partial_order():
    assert dominates((1.0, 1.0), (2.0, 2.0))
    assert not dominates((1.0, 2.0), (2.0, 1.0))  # incomparable
    assert not dominates((1.0, 1.0), (1.0, 1.0))  # equal is not strictly dominating


def test_non_dominated_sort_front_0_is_exactly_the_pareto_set():
    pop = [Individual(np.zeros(1), o) for o in
           [(1.0, 1.0), (2.0, 2.0), (0.5, 3.0), (3.0, 0.5), (2.5, 2.5)]]
    fronts = non_dominated_sort(pop)
    front0_objs = {pop[i].objectives for i in fronts[0]}
    assert front0_objs == {(1.0, 1.0), (0.5, 3.0), (3.0, 0.5)}
    # (2,2) and (2.5,2.5) are both dominated by (1,1) -> later fronts
    assert sum(len(f) for f in fronts) == len(pop)


def test_crowding_distance_is_infinite_at_the_extremes():
    pop = [Individual(np.zeros(1), o) for o in [(0.0, 3.0), (1.0, 2.0), (2.0, 1.0), (3.0, 0.0)]]
    idxs = list(range(len(pop)))
    dist = crowding_distance(pop, idxs)
    assert dist[0] == float("inf")
    assert dist[3] == float("inf")
    assert 0 < dist[1] < float("inf")


def test_environmental_selection_keeps_target_size_and_prefers_better_fronts():
    pop = [Individual(np.zeros(1), o) for o in
           [(0.0, 3.0), (1.0, 2.0), (3.0, 0.0),   # front 0
            (2.0, 2.0), (2.5, 2.5)]]               # dominated
    selected = environmental_selection(pop, target_size=3)
    assert len(selected) == 3
    assert all(s.objectives in {(0.0, 3.0), (1.0, 2.0), (3.0, 0.0)} for s in selected)


def test_external_archive_rejects_dominated_and_duplicate_points():
    archive = ExternalArchive()
    archive.offer(Individual(np.zeros(1), (1.0, 1.0)))
    archive.offer(Individual(np.zeros(1), (2.0, 2.0)))  # dominated by (1,1) -> rejected
    assert archive.front() == [(1.0, 1.0)]
    archive.offer(Individual(np.zeros(1), (1.0, 1.0)))  # exact duplicate -> rejected
    assert len(archive.members) == 1


def test_external_archive_evicts_points_dominated_by_a_new_arrival():
    archive = ExternalArchive()
    archive.offer(Individual(np.zeros(1), (2.0, 2.0)))
    archive.offer(Individual(np.zeros(1), (1.0, 3.0)))  # incomparable, both stay
    assert len(archive.members) == 2
    archive.offer(Individual(np.zeros(1), (1.0, 1.0)))  # dominates both -> both evicted
    assert archive.front() == [(1.0, 1.0)]


def test_external_archive_respects_max_size_via_crowding():
    archive = ExternalArchive(max_size=5)
    rng = np.random.default_rng(0)
    for _ in range(40):
        pt = tuple(rng.uniform(0, 1, 2))
        archive.offer(Individual(np.zeros(1), pt))
    assert len(archive.members) <= 5


def test_lshade_runs_end_to_end_on_the_toy_workflow(toy_workflow, environment):
    def evaluate_fn(genes):
        order, assignment = encoding.decode(toy_workflow, genes, environment.num_nodes)
        return objectives.simulate(toy_workflow, environment, order, assignment).objective_vector

    cfg = LSHADEConfig(dim=encoding.chromosome_length(toy_workflow),
                        pop_size_init=12, pop_size_min=6, max_evals=80)
    de = LSHADE(cfg, np.random.default_rng(0))
    result = de.run(evaluate_fn)

    assert result["evals_used"] >= cfg.max_evals  # loop runs until the budget is exhausted
    assert len(result["front"]) >= 1
    assert all(len(p) == 3 for p in result["front"])
    assert all(np.isfinite(p).all() for p in result["front"])
    # the archive front must itself be non-dominated
    front = result["front"]
    for i, a in enumerate(front):
        for j, b in enumerate(front):
            if i != j:
                assert not dominates(a, b)
    assert "archive_individuals" in result and len(result["archive_individuals"]) == len(front)


def test_lshade_population_shrinks_toward_pop_size_min(toy_workflow, environment):
    def evaluate_fn(genes):
        order, assignment = encoding.decode(toy_workflow, genes, environment.num_nodes)
        return objectives.simulate(toy_workflow, environment, order, assignment).objective_vector

    cfg = LSHADEConfig(dim=encoding.chromosome_length(toy_workflow),
                        pop_size_init=20, pop_size_min=6, max_evals=150)
    de = LSHADE(cfg, np.random.default_rng(1))
    result = de.run(evaluate_fn)
    # environmental_selection() only ever truncates, never pads, so if the
    # eval budget runs out partway through producing the final generation's
    # children, the returned population can end up smaller than
    # pop_size_min -- harmless, since nothing downstream reads
    # final_population (every caller uses the external archive's front
    # instead); only check it never *exceeds* the un-shrunk starting size.
    assert 0 < len(result["final_population"]) <= 20

# Seeds

Empty until you run the generator -- `seeds.json` is a reproducible
artifact, not checked into the repo (see `.gitignore`).

```bash
python scripts/generate_seeds.py
```

Writes `data/seeds/seeds.json`: the 30 evaluation seeds (reproducing
the paper's documented `{11, 23, 37, ..., 331}` shape from one fixed
meta-seed) plus a disjoint block of training seeds used only by the GAT
policy's REINFORCE trainer and the DQN/PPO baselines. See
`scripts/generate_seeds.py`'s module docstring for exactly how, and
what to do if you have the paper's actual recorded seed list instead.

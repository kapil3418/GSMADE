"""Multi-objective quality indicators and the statistical tests used in
Section 6 of the paper: hypervolume, IGD, the Section 6.3 knee-point rule,
and the Friedman / Nemenyi / Wilcoxon procedure of Section 6.5/6.10
(reference [27]: Demsar, "Statistical comparisons of classifiers over
multiple data sets", J. Mach. Learn. Res., 2006 -- already cited in the
paper's reference list; the Nemenyi critical-difference table below is
Demsar's Table 5(b), alpha = 0.05).
"""
from __future__ import annotations

import numpy as np
from scipy import stats

Point = tuple[float, ...]


# --------------------------------------------------------------------------
# Normalization (objectives live on very different scales: seconds, joules,
# dollars) -- every indicator below operates on min-max-normalized vectors,
# with min/max taken over the pooled set of points passed to normalize().
# --------------------------------------------------------------------------
def normalize(points: list[Point]) -> list[Point]:
    arr = np.asarray(points, dtype=float)
    lo = arr.min(axis=0)
    hi = arr.max(axis=0)
    span = np.where(hi - lo > 1e-12, hi - lo, 1.0)
    return [tuple(row) for row in (arr - lo) / span]


def reference_point(points: list[Point], percentile: float = 95.0) -> Point:
    """Per-objective `percentile`-th worst value across the pooled set,
    used instead of the pooled max so that an occasional far-dominated
    vector from a weak baseline (HEFT, Min-Min) does not compress the
    hypervolume differences among the competitive methods (paper,
    Section 6.3)."""
    arr = np.asarray(points, dtype=float)
    return tuple(np.percentile(arr, percentile, axis=0) + 1e-9)


def dominates(a: Point, b: Point) -> bool:
    """a dominates b under minimization."""
    return all(x <= y for x, y in zip(a, b)) and any(x < y for x, y in zip(a, b))


def pareto_front(points: list[Point]) -> list[Point]:
    front = []
    for p in points:
        if not any(dominates(q, p) for q in points if q != p):
            front.append(p)
    # de-duplicate while preserving order
    seen = set()
    out = []
    for p in front:
        if p not in seen:
            seen.add(p)
            out.append(p)
    return out


# --------------------------------------------------------------------------
# Hypervolume (exact, dimension-sweep; correct for any dimension >= 2 but
# used here for the paper's 3-objective fronts, each with <=12 points, so
# the straightforward O(n^2) sweep below is more than fast enough).
# --------------------------------------------------------------------------
def _hv_2d(points_xy: list[tuple[float, float]], ref_x: float, ref_y: float) -> float:
    pts = sorted(set(points_xy))
    front: list[tuple[float, float]] = []
    best_y = float("inf")
    for x, y in pts:
        if y < best_y:
            front.append((x, y))
            best_y = y
    area = 0.0
    for i, (x, y) in enumerate(front):
        next_x = front[i + 1][0] if i + 1 < len(front) else ref_x
        width = max(next_x - x, 0.0)
        height = max(ref_y - y, 0.0)
        area += width * height
    return area


def hypervolume(points: list[Point], ref: Point) -> float:
    """Exact dominated hypervolume relative to reference point `ref`
    (minimization; `ref` must be weakly worse than every point in every
    objective). Implemented via dimension-sweep on the 3rd objective and
    an exact 2D sweep on the remaining two -- correct for the paper's
    3-objective (makespan, energy, cost) fronts."""
    if not points:
        return 0.0
    assert len(ref) == 3, "this implementation targets the paper's 3-objective case"
    clipped = [p for p in points if all(pi <= ri for pi, ri in zip(p, ref))]
    if not clipped:
        return 0.0
    z_breaks = sorted(set(p[2] for p in clipped))
    hv = 0.0
    for i, z in enumerate(z_breaks):
        active_xy = [(p[0], p[1]) for p in clipped if p[2] <= z]
        area = _hv_2d(active_xy, ref[0], ref[1])
        next_z = z_breaks[i + 1] if i + 1 < len(z_breaks) else ref[2]
        hv += area * max(next_z - z, 0.0)
    return hv


# --------------------------------------------------------------------------
# Inverted Generational Distance. The reference set is the non-dominated
# union of every method's output vector for one instance (paper subheading:
# "The inverted-generational-distance reference set").
# --------------------------------------------------------------------------
def build_igd_reference_set(all_methods_points: list[Point]) -> list[Point]:
    return pareto_front(all_methods_points)


def igd(front: list[Point], reference_set: list[Point]) -> float:
    if not reference_set:
        return 0.0
    if not front:
        return float("inf")
    f = np.asarray(front, dtype=float)
    total = 0.0
    for r in reference_set:
        d = np.sqrt(((f - np.asarray(r)) ** 2).sum(axis=1)).min()
        total += d
    return total / len(reference_set)


# --------------------------------------------------------------------------
# Knee point (Section 6.3): for M objectives, the extreme set is the M
# points each minimizing one normalized objective; the knee is the point
# of largest perpendicular distance to the hyperplane through them. Ties
# go to the most balanced point (smallest range across normalized
# objectives); a disconnected non-dominated set is restricted to the
# component containing a deadline-feasible point by the caller.
# --------------------------------------------------------------------------
def knee_point(front: list[Point]) -> Point:
    if len(front) == 1:
        return front[0]
    arr = np.asarray(front, dtype=float)
    m = arr.shape[1]
    extreme_idx = [int(np.argmin(arr[:, j])) for j in range(m)]
    extremes = arr[extreme_idx]

    # Fit hyperplane n.x = d through the M extreme points (solve the linear
    # system augmented with ||n||=1 via least squares on a homogeneous
    # system: stack [extremes, -1] @ [n; d] = 0, take the right null vector).
    A = np.hstack([extremes, -np.ones((m, 1))])
    _, _, vt = np.linalg.svd(A)
    n_d = vt[-1]
    normal, d = n_d[:-1], n_d[-1]
    norm = np.linalg.norm(normal) + 1e-12

    signed = (arr @ normal - d) / norm
    # the "good" side (closer to the origin / better in every objective)
    # is the side the centroid of extremes is NOT on relative to typical
    # interior points; take the side with the most points as the feasible
    # bulge and maximize distance on that side.
    side = np.sign(signed)
    main_side = 1 if (side > 0).sum() >= (side <= 0).sum() else -1
    candidates = np.where(side == main_side)[0]
    if len(candidates) == 0:
        candidates = np.arange(len(front))
    dists = np.abs(signed[candidates])
    best = candidates[np.argmax(dists)]

    # tie-break: most balanced point (smallest spread across normalized
    # objectives) among near-ties within 1% of the max distance
    max_d = dists.max()
    tied = [candidates[i] for i, dval in enumerate(dists) if dval >= max_d * 0.99]
    if len(tied) > 1:
        spreads = [arr[i].max() - arr[i].min() for i in tied]
        best = tied[int(np.argmin(spreads))]
    return tuple(arr[best])


# --------------------------------------------------------------------------
# Friedman / Nemenyi / Wilcoxon (Section 6.5 / 6.10; reference [27]).
# --------------------------------------------------------------------------
def friedman_test(rank_matrix: np.ndarray) -> tuple[float, float]:
    """rank_matrix: (n_blocks, k_treatments) raw performance values (not
    pre-ranked); returns (chi2, p_value) via scipy's implementation."""
    cols = [rank_matrix[:, j] for j in range(rank_matrix.shape[1])]
    chi2, p = stats.friedmanchisquare(*cols)
    return float(chi2), float(p)


def mean_ranks(rank_matrix: np.ndarray) -> np.ndarray:
    """Average rank per treatment (column), lower value = better = rank 1,
    averaging tied ranks, then averaged across blocks (rows)."""
    ranks = np.apply_along_axis(stats.rankdata, 1, rank_matrix)
    return ranks.mean(axis=0)


# Demsar (2006), Table 5(b): studentized range statistic q_alpha for the
# Nemenyi test at alpha = 0.05, indexed by number of treatments k.
_Q_ALPHA_005 = {
    2: 1.960, 3: 2.343, 4: 2.569, 5: 2.728, 6: 2.850, 7: 2.949, 8: 3.031,
    9: 3.102, 10: 3.164, 11: 3.219, 12: 3.268, 13: 3.313, 14: 3.354,
    15: 3.391, 16: 3.426, 17: 3.458, 18: 3.489, 19: 3.517, 20: 3.544,
}


def nemenyi_critical_difference(k: int, n_blocks: int, alpha: float = 0.05) -> float:
    if alpha != 0.05:
        raise NotImplementedError("only the alpha=0.05 table from Demsar (2006) is bundled")
    q = _Q_ALPHA_005[k]
    return q * np.sqrt(k * (k + 1) / (6.0 * n_blocks))


def wilcoxon_signed_rank(a: np.ndarray, b: np.ndarray) -> tuple[float, float]:
    stat, p = stats.wilcoxon(a, b)
    return float(stat), float(p)


def paired_confidence_interval(diffs: np.ndarray, confidence: float = 0.95) -> tuple[float, float, float]:
    """Mean and a t-distribution confidence interval on paired differences
    (Section 6.10's family-level hypervolume-advantage CI)."""
    diffs = np.asarray(diffs, dtype=float)
    mean = diffs.mean()
    sem = stats.sem(diffs)
    n = len(diffs)
    tval = stats.t.ppf(0.5 + confidence / 2.0, df=n - 1)
    half_width = tval * sem
    return float(mean), float(mean - half_width), float(mean + half_width)

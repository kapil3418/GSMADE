"""Adaptive differential evolution: a multi-objective L-SHADE.

Single-objective L-SHADE (Tanabe & Fukunaga, 2014 -- reference [15],
already cited by the paper) adapts its scale factor F and crossover rate
CR from a success-history memory (H slots of (M_F, M_CR), updated by a
weighted Lehmer mean of the trials that actually improved on their
parent) and linearly shrinks the population from NP_init to NP_min over
the evaluation budget (LPSR). This module keeps exactly that adaptation
mechanism and extends survivor selection to three objectives GDE3-style:
a trial that Pareto-dominates its parent replaces it outright; a parent
that dominates its trial is kept outright; a mutually non-dominated pair
both survive into an oversized population, which is then truncated back
to the (shrinking) target size by non-dominated sorting + crowding
distance, exactly as NSGA-II's (reference [18]) environmental selection.

An external non-dominated archive accumulates every individual evaluated
during the run, independent of population truncation, and is what
scripts/run_evaluation.py reads off as the method's final front.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable

import numpy as np


@dataclass
class Individual:
    genes: np.ndarray
    objectives: tuple[float, ...] | None = None


def dominates(a: tuple[float, ...], b: tuple[float, ...]) -> bool:
    return all(x <= y for x, y in zip(a, b)) and any(x < y for x, y in zip(a, b))


def non_dominated_sort(pop: list[Individual]) -> list[list[int]]:
    n = len(pop)
    dom_count = [0] * n
    dominates_list: list[list[int]] = [[] for _ in range(n)]
    fronts: list[list[int]] = [[]]
    for i in range(n):
        for j in range(n):
            if i == j:
                continue
            if dominates(pop[i].objectives, pop[j].objectives):
                dominates_list[i].append(j)
            elif dominates(pop[j].objectives, pop[i].objectives):
                dom_count[i] += 1
        if dom_count[i] == 0:
            fronts[0].append(i)
    k = 0
    while fronts[k]:
        nxt = []
        for i in fronts[k]:
            for j in dominates_list[i]:
                dom_count[j] -= 1
                if dom_count[j] == 0:
                    nxt.append(j)
        k += 1
        fronts.append(nxt)
    return fronts[:-1]


def crowding_distance(pop: list[Individual], idxs: list[int]) -> dict[int, float]:
    m = len(pop[idxs[0]].objectives)
    dist = {i: 0.0 for i in idxs}
    for obj_i in range(m):
        ordered = sorted(idxs, key=lambda i: pop[i].objectives[obj_i])
        lo, hi = pop[ordered[0]].objectives[obj_i], pop[ordered[-1]].objectives[obj_i]
        span = max(hi - lo, 1e-12)
        dist[ordered[0]] = dist[ordered[-1]] = float("inf")
        for k in range(1, len(ordered) - 1):
            prev_v = pop[ordered[k - 1]].objectives[obj_i]
            next_v = pop[ordered[k + 1]].objectives[obj_i]
            dist[ordered[k]] += (next_v - prev_v) / span
    return dist


def environmental_selection(pop: list[Individual], target_size: int) -> list[Individual]:
    if len(pop) <= target_size:
        return pop
    fronts = non_dominated_sort(pop)
    selected: list[int] = []
    for front in fronts:
        if len(selected) + len(front) <= target_size:
            selected.extend(front)
        else:
            remaining = target_size - len(selected)
            dist = crowding_distance(pop, front)
            front_sorted = sorted(front, key=lambda i: -dist[i])
            selected.extend(front_sorted[:remaining])
            break
    return [pop[i] for i in selected]


@dataclass
class ExternalArchive:
    members: list[Individual] = field(default_factory=list)
    max_size: int = 200

    def offer(self, ind: Individual) -> None:
        if any(m.objectives == ind.objectives for m in self.members):
            return
        if any(dominates(m.objectives, ind.objectives) for m in self.members):
            return
        self.members = [m for m in self.members if not dominates(ind.objectives, m.objectives)]
        self.members.append(ind)
        if len(self.members) > self.max_size:
            fronts = non_dominated_sort(self.members)
            kept: list[int] = []
            for front in fronts:
                if len(kept) + len(front) <= self.max_size:
                    kept.extend(front)
                else:
                    dist = crowding_distance(self.members, front)
                    kept.extend(sorted(front, key=lambda i: -dist[i])[:self.max_size - len(kept)])
                    break
            self.members = [self.members[i] for i in kept]

    def front(self) -> list[tuple[float, ...]]:
        return [m.objectives for m in self.members]


@dataclass
class LSHADEConfig:
    dim: int
    pop_size_init: int = 40
    pop_size_min: int = 8
    max_evals: int = 4000
    memory_size: int = 6     # H
    p_rate: float = 0.1      # current-to-pbest/1's "p"
    archive_rate: float = 2.0


class LSHADE:
    """One run = one (workflow, environment) pair. Call `run(evaluate_fn)`
    with evaluate_fn(genes: np.ndarray) -> tuple[float, float, float]."""

    def __init__(self, config: LSHADEConfig, rng: np.random.Generator):
        self.cfg = config
        self.rng = rng
        self.m_f = np.full(config.memory_size, 0.5)
        self.m_cr = np.full(config.memory_size, 0.5)
        self.mem_pos = 0
        self.archive_genes: list[np.ndarray] = []
        self.external_archive = ExternalArchive()
        self.evals_used = 0

    def _sample_f_cr(self) -> tuple[float, float]:
        k = self.rng.integers(0, self.cfg.memory_size)
        cr = np.clip(self.rng.normal(self.m_cr[k], 0.1), 0.0, 1.0)
        f = -1.0
        while f <= 0.0:
            f = self.m_f[k] + 0.1 * np.tan(np.pi * (self.rng.random() - 0.5))  # Cauchy(m_f[k], 0.1)
        return float(min(f, 1.0)), float(cr), k

    def _mutate(self, pop: list[Individual], i: int, f: float) -> np.ndarray:
        d = self.cfg.dim
        n = len(pop)
        p_best_n = max(1, int(round(self.cfg.p_rate * n)))
        ranked = sorted(range(n), key=lambda idx: pop[idx].objectives)  # lexicographic proxy rank
        pbest_idx = ranked[self.rng.integers(0, p_best_n)]

        r1 = i
        while r1 == i:
            r1 = int(self.rng.integers(0, n))
        pool_genes = [pop[j].genes for j in range(n) if j not in (i, r1)] + self.archive_genes
        r2_genes = pool_genes[int(self.rng.integers(0, len(pool_genes)))] if pool_genes else pop[i].genes

        x_i = pop[i].genes
        v = x_i + f * (pop[pbest_idx].genes - x_i) + f * (pop[r1].genes - r2_genes)
        return np.clip(v, 0.0, 0.999999)

    def _crossover(self, parent: np.ndarray, mutant: np.ndarray, cr: float) -> np.ndarray:
        d = len(parent)
        mask = self.rng.random(d) < cr
        mask[self.rng.integers(0, d)] = True  # guarantee at least one mutant gene
        return np.where(mask, mutant, parent)

    def run(self, evaluate_fn: Callable[[np.ndarray], tuple[float, float, float]],
            initial_population: np.ndarray | None = None,
            post_generation_hook: Callable[["LSHADE", list[Individual], int], list[Individual]] | None = None
            ) -> dict:
        """`post_generation_hook(self, population, generation_idx) ->
        population` runs after each generation's environmental selection
        -- this is GS-MADE's hook point for periodic VNS intensification
        (see gsmade/scheduler.py). The hook may call back into this same
        LSHADE instance (e.g. `self.external_archive.offer(...)`,
        `self.evals_used += k`) so extra simulator calls it performs are
        still charged against the shared evaluation budget."""
        cfg = self.cfg
        pop: list[Individual] = []
        if initial_population is not None:
            for genes in initial_population[:cfg.pop_size_init]:
                pop.append(Individual(genes.copy()))
        while len(pop) < cfg.pop_size_init:
            pop.append(Individual(self.rng.random(cfg.dim)))

        for ind in pop:
            ind.objectives = evaluate_fn(ind.genes)
            self.evals_used += 1
            self.external_archive.offer(Individual(ind.genes.copy(), ind.objectives))

        max_archive = int(round(cfg.archive_rate * cfg.pop_size_init))
        current_np = cfg.pop_size_init
        generation = 0

        while self.evals_used < cfg.max_evals:
            s_f, s_cr, s_w = [], [], []
            children: list[Individual] = []
            for i in range(len(pop)):
                f, cr, k = self._sample_f_cr()
                mutant = self._mutate(pop, i, f)
                trial_genes = self._crossover(pop[i].genes, mutant, cr)
                trial_obj = evaluate_fn(trial_genes)
                self.evals_used += 1
                trial = Individual(trial_genes, trial_obj)
                self.external_archive.offer(Individual(trial_genes.copy(), trial_obj))

                if dominates(trial.objectives, pop[i].objectives):
                    improvement = sum(a - b for a, b in zip(pop[i].objectives, trial.objectives))
                    s_f.append(f); s_cr.append(cr); s_w.append(max(improvement, 1e-12))
                    self.archive_genes.append(pop[i].genes.copy())
                    children.append(trial)
                elif dominates(pop[i].objectives, trial.objectives):
                    children.append(pop[i])
                else:
                    children.append(pop[i])
                    children.append(trial)

                if self.evals_used >= cfg.max_evals:
                    break

            if len(self.archive_genes) > max_archive:
                keep_idx = self.rng.choice(len(self.archive_genes), size=max_archive, replace=False)
                self.archive_genes = [self.archive_genes[i] for i in keep_idx]

            if s_f:
                w = np.array(s_w); w = w / w.sum()
                f_arr, cr_arr = np.array(s_f), np.array(s_cr)
                self.m_f[self.mem_pos] = float((w * f_arr ** 2).sum() / max((w * f_arr).sum(), 1e-12))
                self.m_cr[self.mem_pos] = float((w * cr_arr).sum())
                self.mem_pos = (self.mem_pos + 1) % cfg.memory_size

            # linear population-size reduction
            progress = min(self.evals_used / cfg.max_evals, 1.0)
            current_np = max(cfg.pop_size_min, round(cfg.pop_size_init
                              - progress * (cfg.pop_size_init - cfg.pop_size_min)))
            pop = environmental_selection(children, current_np)
            generation += 1
            if post_generation_hook is not None:
                pop = post_generation_hook(self, pop, generation)

        return {
            "final_population": pop,
            "archive_individuals": list(self.external_archive.members),
            "front": self.external_archive.front(),
            "evals_used": self.evals_used,
        }

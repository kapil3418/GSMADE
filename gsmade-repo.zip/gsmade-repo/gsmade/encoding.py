"""Largest-Rank-Value (LRV) encoding/decoding.

Every population-based method in this repo (GS-MADE's own L-SHADE stage,
and the PSO/GWO/NSGA-II/cold-start-L-SHADE/IPSO-GWO/IMOMA baselines)
searches over the same real-valued chromosome so that a result difference
reflects the search strategy, not the representation (paper, Section
"Every population baseline shares the same largest-rank-value decoding").

Chromosome layout, length 2 * n_tasks, values in [0, 1):
    genes[0 : n]      -- priority key per task (higher = scheduled earlier
                          among its currently-ready competitors)
    genes[n : 2n]     -- resource key per task, floor(key * n_nodes) picks
                          the assigned node

Decoding never produces a precedence-infeasible schedule: tasks are only
ever picked from the "ready" frontier (all predecessors already placed),
so no repair operator is needed -- this is what the paper means by
"every seed is precedence-feasible by construction".
"""
from __future__ import annotations

import heapq

import numpy as np

from .workflow import Workflow


def chromosome_length(workflow: Workflow) -> int:
    return 2 * workflow.num_tasks


def decode_order(workflow: Workflow, priority_genes: np.ndarray) -> list[int]:
    """Topological order consistent with precedence, breaking ties among
    ready tasks by descending priority key (largest rank value first)."""
    task_ids = sorted(workflow.tasks.keys())
    gene_of = {tid: priority_genes[i] for i, tid in enumerate(task_ids)}
    indeg = {tid: workflow.graph.in_degree(tid) for tid in task_ids}

    # max-heap via negated priority; tie-break on task_id for determinism
    ready: list[tuple[float, int]] = [(-gene_of[t], t) for t in task_ids if indeg[t] == 0]
    heapq.heapify(ready)

    order: list[int] = []
    remaining_indeg = dict(indeg)
    while ready:
        _, u = heapq.heappop(ready)
        order.append(u)
        for v in workflow.successors(u):
            remaining_indeg[v] -= 1
            if remaining_indeg[v] == 0:
                heapq.heappush(ready, (-gene_of[v], v))
    assert len(order) == len(task_ids), "cycle or disconnected DAG in decode_order"
    return order


def decode_assignment(workflow: Workflow, resource_genes: np.ndarray, num_nodes: int) -> dict[int, int]:
    task_ids = sorted(workflow.tasks.keys())
    assignment = {}
    for i, tid in enumerate(task_ids):
        key = min(max(resource_genes[i], 0.0), 0.999999)
        assignment[tid] = int(key * num_nodes)
    return assignment


def decode(workflow: Workflow, genes: np.ndarray, num_nodes: int) -> tuple[list[int], dict[int, int]]:
    n = workflow.num_tasks
    order = decode_order(workflow, genes[:n])
    assignment = decode_assignment(workflow, genes[n:2 * n], num_nodes)
    return order, assignment


def random_genes(workflow: Workflow, rng: np.random.Generator) -> np.ndarray:
    return rng.random(chromosome_length(workflow))


def genes_from_priority_vector(priority: np.ndarray, resource: np.ndarray) -> np.ndarray:
    """Pack a (priority, resource) pair -- e.g. the GAT policy's output --
    into the shared chromosome layout used by every search operator."""
    return np.concatenate([priority, resource])

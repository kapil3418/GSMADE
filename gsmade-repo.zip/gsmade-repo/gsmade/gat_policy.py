"""Graph-attention seeding policy, trained once per workflow family.

Architecture: a 2-layer graph attention network (Velickovic et al. 2018,
reference [17]) embeds every task from its local neighborhood (both
predecessors and successors, so information flows both ways along the
DAG), conditioned on a Dirichlet-sampled objective-preference vector
appended to every node's input features. Two linear heads turn each
task's embedding into a diagonal Gaussian over the (priority, resource)
genes of gsmade/encoding.py's chromosome; sampling and squashing through
a sigmoid produces a precedence-feasible, LRV-decodable seed.

Training: REINFORCE (Williams, 1992 -- reference [20], already cited by
the paper) with a running-mean baseline. The policy gradient identity
grad_theta E_z[R] = E_z[R * grad_theta log p(z; theta)] holds regardless
of the deterministic sigmoid squash applied to the sampled z before it
reaches the environment, so no change-of-variables correction is needed
-- see the module docstring in gsmade/nn.py for the broader design note.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .nn import Adam, Linear, Tensor
from .workflow import Workflow

LOG_2PI = float(np.log(2 * np.pi))


class GraphAttentionLayer:
    def __init__(self, in_dim: int, out_dim: int, rng: np.random.Generator):
        self.W = Linear(in_dim, out_dim, rng)
        self.a = Linear(2 * out_dim, 1, rng)
        self.out_dim = out_dim

    def __call__(self, x: Tensor, adjacency: list[list[int]]) -> Tensor:
        h = self.W(x)  # (n, out_dim), no bias-free requirement -- Linear includes bias
        n = h.shape[0]
        rows = []
        for i in range(n):
            neighbors = adjacency[i]
            k = len(neighbors)
            h_i_rep = h[[i] * k]
            h_nbrs = h[neighbors]
            feats = Tensor.concat([h_i_rep, h_nbrs], axis=1)  # (k, 2*out_dim)
            e = self.a(feats).leaky_relu(0.2)  # (k, 1)
            alpha = e.softmax(axis=0)  # normalize over the k neighbors
            weighted = (alpha * h_nbrs).sum(axis=0, keepdims=False)  # (out_dim,)
            rows.append(weighted.reshape((1, self.out_dim)))
        return Tensor.concat(rows, axis=0).tanh()

    def params(self) -> list[Tensor]:
        return self.W.params() + self.a.params()


def build_adjacency(workflow: Workflow, self_loops: bool = True) -> list[list[int]]:
    """Undirected neighbor list (predecessors + successors), indexed by
    the same 0..n-1 ordering used everywhere else in this repo (sorted
    task ids)."""
    task_ids = sorted(workflow.tasks.keys())
    pos = {tid: i for i, tid in enumerate(task_ids)}
    adjacency: list[list[int]] = [[] for _ in task_ids]
    for tid in task_ids:
        i = pos[tid]
        nbrs = set(workflow.predecessors(tid)) | set(workflow.successors(tid))
        adjacency[i] = sorted(pos[n] for n in nbrs)
        if self_loops or not adjacency[i]:
            adjacency[i].append(i)
    return adjacency


def node_features(workflow: Workflow, preference: np.ndarray) -> np.ndarray:
    """7-dim input per task: [workload, in-deg, out-deg, topo-level]
    (each min-max normalized within the instance) concatenated with the
    3-weight Dirichlet preference vector shared by every node."""
    task_ids = sorted(workflow.tasks.keys())
    workloads = np.array([workflow.tasks[t].workload_mi for t in task_ids])
    indeg = np.array([workflow.graph.in_degree(t) for t in task_ids], dtype=float)
    outdeg = np.array([workflow.graph.out_degree(t) for t in task_ids], dtype=float)

    levels = {}
    import networkx as nx
    for n in nx.topological_sort(workflow.graph):
        preds = list(workflow.graph.predecessors(n))
        levels[n] = 0 if not preds else 1 + max(levels[p] for p in preds)
    topo_level = np.array([levels[t] for t in task_ids], dtype=float)

    def norm(x):
        span = x.max() - x.min()
        return (x - x.min()) / span if span > 1e-9 else np.zeros_like(x)

    feats = np.stack([norm(workloads), norm(indeg), norm(outdeg), norm(topo_level)], axis=1)
    pref_tile = np.tile(preference.reshape(1, -1), (len(task_ids), 1))
    return np.concatenate([feats, pref_tile], axis=1)


@dataclass
class SampledGenes:
    genes: np.ndarray       # (2n,) in [0,1), ready for encoding.decode()
    log_prob: Tensor        # scalar Tensor, differentiable w.r.t. policy params


class GATPolicy:
    INPUT_DIM = 4 + 3  # structural features + 3-weight preference vector

    def __init__(self, hidden_dim: int = 16, seed: int = 0):
        self.rng = np.random.default_rng(seed)
        self.gat1 = GraphAttentionLayer(self.INPUT_DIM, hidden_dim, self.rng)
        self.gat2 = GraphAttentionLayer(hidden_dim, hidden_dim, self.rng)
        self.head_priority = Linear(hidden_dim, 2, self.rng)  # (mu, raw_log_std)
        self.head_resource = Linear(hidden_dim, 2, self.rng)

    def params(self) -> list[Tensor]:
        return (self.gat1.params() + self.gat2.params()
                + self.head_priority.params() + self.head_resource.params())

    def _embed(self, workflow: Workflow, preference: np.ndarray) -> Tensor:
        adjacency = build_adjacency(workflow)
        x = Tensor(node_features(workflow, preference))
        h = self.gat1(x, adjacency)
        h = self.gat2(h, adjacency)
        return h

    def sample(self, workflow: Workflow, preference: np.ndarray, deterministic: bool = False) -> SampledGenes:
        h = self._embed(workflow, preference)
        n = workflow.num_tasks

        def head_to_dist(head):
            out = head(h)  # (n, 2)
            mu = out[:, 0:1]
            raw_log_std = out[:, 1:2]
            log_std = raw_log_std.tanh() * 1.0 - 1.0  # squashed to [-2, 0] -> std in [0.135, 1]
            return mu, log_std

        mu_p, logstd_p = head_to_dist(self.head_priority)
        mu_r, logstd_r = head_to_dist(self.head_resource)

        if deterministic:
            z_p = mu_p.data.reshape(n)
            z_r = mu_r.data.reshape(n)
        else:
            z_p = mu_p.data.reshape(n) + np.exp(logstd_p.data.reshape(n)) * self.rng.normal(size=n)
            z_r = mu_r.data.reshape(n) + np.exp(logstd_r.data.reshape(n)) * self.rng.normal(size=n)

        logp = (_gaussian_log_prob(Tensor(z_p.reshape(n, 1)), mu_p, logstd_p)
                + _gaussian_log_prob(Tensor(z_r.reshape(n, 1)), mu_r, logstd_r)).sum()

        genes = np.concatenate([_sigmoid_np(z_p), _sigmoid_np(z_r)])
        return SampledGenes(genes=genes, log_prob=logp)


def _sigmoid_np(x: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-x))


def _gaussian_log_prob(z: Tensor, mu: Tensor, log_std: Tensor) -> Tensor:
    std = log_std.exp()
    diff = (z - mu) / std
    return (diff.pow(2.0) * -0.5) - log_std - (0.5 * LOG_2PI)


class ReinforceTrainer:
    """REINFORCE with a running-mean baseline. One "episode" = one sampled
    schedule for one (workflow, Dirichlet preference) pair; the reward is
    the negative min-max-normalized weighted-sum of the three objectives
    (normalization bounds are refreshed from a rolling window so the
    reward scale stays roughly stationary across training)."""

    def __init__(self, policy: GATPolicy, lr: float = 3e-3):
        self.policy = policy
        self.opt = Adam(policy.params(), lr=lr)
        self.baseline = 0.0
        self.baseline_momentum = 0.9
        self._obj_lo = None
        self._obj_hi = None

    def _normalize_objectives(self, vec: np.ndarray) -> np.ndarray:
        if self._obj_lo is None:
            self._obj_lo, self._obj_hi = vec.copy(), vec.copy() + 1e-6
        self._obj_lo = np.minimum(self._obj_lo, vec)
        self._obj_hi = np.maximum(self._obj_hi, vec)
        span = np.maximum(self._obj_hi - self._obj_lo, 1e-9)
        return (vec - self._obj_lo) / span

    def step(self, workflow: Workflow, environment, preference: np.ndarray, num_nodes: int) -> dict:
        from . import encoding, objectives

        sample = self.policy.sample(workflow, preference)
        order, assignment = encoding.decode(workflow, sample.genes, num_nodes)
        result = objectives.simulate(workflow, environment, order, assignment)
        obj = np.array(result.objective_vector)
        norm_obj = self._normalize_objectives(obj)
        scalarized = float(preference @ norm_obj)
        reward = -scalarized
        deadline_bonus = 0.1 if result.deadline_met else 0.0
        reward += deadline_bonus

        self.baseline = self.baseline_momentum * self.baseline + (1 - self.baseline_momentum) * reward
        advantage = reward - self.baseline

        self.opt.zero_grad()
        loss = sample.log_prob * (-advantage)
        loss.backward()
        self.opt.step()

        return {"reward": reward, "advantage": advantage, "objective_vector": result.objective_vector,
                "deadline_met": result.deadline_met}

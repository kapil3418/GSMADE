"""Variable neighbourhood search: four graph-aware moves (N1-N4), each
aimed at a named objective, plus the shake-then-descend driver.

  N1 -- migrate a critical-path task to the resource minimizing its own
        earliest finish time (attacks f1, makespan).
  N2 -- move a task across the fog<->cloud boundary (trades f2 energy
        against f3 cost).
  N3 -- relieve the most heavily utilized resource by moving one of its
        tasks elsewhere.
  N4 -- co-locate a task with its dominant predecessor (the predecessor
        contributing the most data), eliminating that transfer and
        reducing the communication term of Eq. (2).

N1/N4 use the workflow's structural critical path (same proxy
objectives.py's `_critical_path_tasks` uses, and the same notion Table
2's "Depth" column is built from) rather than re-deriving a schedule-
specific critical path, to keep one definition of "critical path"
consistent across the whole repo.

Moves are proposed on the *decoded* (order, assignment) pair and, once
accepted, re-encoded back into the shared LRV gene representation (see
`reencode`) so the DE population and the VNS-improved individuals live
in exactly the same chromosome space -- "improved individuals are
written back re-encoded, so both metaheuristics share one population."
"""
from __future__ import annotations

import networkx as nx
import numpy as np

from . import objectives
from .encoding import chromosome_length
from .environment import Environment
from .lshade import Individual, dominates
from .workflow import Workflow


def structural_critical_path(workflow: Workflow) -> list[int]:
    return nx.dag_longest_path(workflow.graph, weight=None)


def reencode(workflow: Workflow, order: list[int], assignment: dict[int, int], num_nodes: int) -> np.ndarray:
    """Exact round-trip inverse of encoding.decode(): priority genes are
    set to strictly decreasing values in `order`'s rank, and resource
    genes are set to the midpoint of the target node's bucket in [0,1)
    -- both guarantee decode() reproduces this exact (order, assignment)."""
    task_ids = sorted(workflow.tasks.keys())
    pos = {tid: i for i, tid in enumerate(task_ids)}
    n = len(task_ids)
    rank = {tid: r for r, tid in enumerate(order)}
    genes = np.zeros(chromosome_length(workflow))
    for tid in task_ids:
        i = pos[tid]
        genes[i] = 1.0 - rank[tid] / n
        genes[n + i] = (assignment[tid] + 0.5) / num_nodes
    return genes


def _random_task(workflow: Workflow, rng: np.random.Generator) -> int:
    ids = list(workflow.tasks.keys())
    return ids[int(rng.integers(0, len(ids)))]


def n1_move(workflow, environment: Environment, order, assignment, result, rng, eval_counter=None):
    """Migrate a critical-path task to the node minimizing its own EFT.

    Unlike N2-N4, this evaluates every node in the environment to pick
    the best one, so it costs `len(environment.nodes)` simulate() calls
    on its own -- `eval_counter`, if given, is incremented once per call
    so the caller (vns_local_search) can charge this against a shared
    evaluation budget instead of it being invisible overhead."""
    cp = structural_critical_path(workflow)
    tid = cp[int(rng.integers(0, len(cp)))]
    best_node, best_eft = assignment[tid], None
    for node in environment.nodes:
        trial = dict(assignment)
        trial[tid] = node.node_id
        res = objectives.simulate(workflow, environment, order, trial)
        if eval_counter is not None:
            eval_counter[0] += 1
        eft = res.finish[tid]
        if best_eft is None or eft < best_eft:
            best_eft, best_node = eft, node.node_id
    new_assignment = dict(assignment)
    new_assignment[tid] = best_node
    return new_assignment


def n2_move(workflow, environment: Environment, order, assignment, result, rng, eval_counter=None):
    """Move a random task across the fog<->cloud tier boundary."""
    nodes = environment.nodes
    tid = _random_task(workflow, rng)
    cur_tier = nodes[assignment[tid]].tier
    target_tier = "cloud" if cur_tier != "cloud" else "fog"
    candidates = environment.nodes_of_tier(target_tier)
    if not candidates:
        candidates = environment.nodes_of_tier("fog" if target_tier == "cloud" else "cloud")
    pick = candidates[int(rng.integers(0, len(candidates)))]
    new_assignment = dict(assignment)
    new_assignment[tid] = pick.node_id
    return new_assignment


def n3_move(workflow, environment: Environment, order, assignment, result, rng, eval_counter=None):
    """Relieve the most heavily utilized node by moving one of its tasks
    to the currently least-utilized node."""
    busy = {n.node_id: 0.0 for n in environment.nodes}
    for tid, nid in result.node_of.items():
        busy[nid] += result.finish[tid] - result.start[tid]
    busiest = max(busy, key=busy.get)
    idlest = min(busy, key=busy.get)
    on_busiest = [t for t, nid in result.node_of.items() if nid == busiest]
    if not on_busiest:
        return dict(assignment)
    tid = on_busiest[int(rng.integers(0, len(on_busiest)))]
    new_assignment = dict(assignment)
    new_assignment[tid] = idlest
    return new_assignment


def n4_move(workflow, environment: Environment, order, assignment, result, rng, eval_counter=None):
    """Co-locate a task with its dominant predecessor (largest incoming
    data volume), eliminating that transfer."""
    candidates = [t for t in workflow.tasks if workflow.predecessors(t)]
    if not candidates:
        return dict(assignment)
    tid = candidates[int(rng.integers(0, len(candidates)))]
    preds = workflow.predecessors(tid)
    dominant = max(preds, key=lambda p: workflow.edge_data_mb(p, tid))
    new_assignment = dict(assignment)
    new_assignment[tid] = assignment[dominant]
    return new_assignment


NEIGHBORHOODS = [n1_move, n2_move, n3_move, n4_move]


def vns_local_search(workflow: Workflow, environment: Environment, genes: np.ndarray,
                      num_nodes: int, rng: np.random.Generator, k_max: int = 4,
                      trials_per_neighborhood: int = 6, archive=None,
                      max_calls: int | None = None) -> tuple[np.ndarray, tuple, int]:
    """Shake-then-descend over N1..N4. Returns (new_genes, new_objectives,
    simulate_calls_used). `archive`, if given, is offered every
    incomparable neighbour visited (an ExternalArchive from
    gsmade.lshade), so it can still enter the reported front even though
    it did not replace the incumbent.

    `k` resets to 1 on every improving move (standard VNS), so on a
    far-from-converged starting individual this loop can run for a
    while -- every simulate() call it makes is counted (including N1's
    internal per-node search, see n1_move), and `max_calls`, if given,
    stops the search once that count is reached, so a caller tracking a
    shared evaluation budget (see gsmade/scheduler.py's `_vns_hook`,
    which is what every scripts/run_*.py goes through) can bound this
    call's wall-clock cost by the budget actually remaining rather than
    letting it run unboundedly."""
    from .encoding import decode

    eval_counter = [0]

    def _budget_left() -> bool:
        return max_calls is None or eval_counter[0] < max_calls

    order, assignment = decode(workflow, genes, num_nodes)
    result = objectives.simulate(workflow, environment, order, assignment)
    eval_counter[0] += 1
    current_obj = result.objective_vector

    k = 1
    while k <= k_max and _budget_left():
        improved = False
        move_fn = NEIGHBORHOODS[k - 1]
        for _ in range(trials_per_neighborhood):
            if not _budget_left():
                break
            cand_assignment = move_fn(workflow, environment, order, assignment, result, rng, eval_counter)
            cand_result = objectives.simulate(workflow, environment, order, cand_assignment)
            eval_counter[0] += 1
            cand_obj = cand_result.objective_vector
            if dominates(cand_obj, current_obj):
                assignment, result, current_obj = cand_assignment, cand_result, cand_obj
                improved = True
                break
            elif not dominates(current_obj, cand_obj) and archive is not None:
                cand_genes = reencode(workflow, order, cand_assignment, num_nodes)
                archive.offer(Individual(cand_genes, cand_obj))
        k = 1 if improved else k + 1

    new_genes = reencode(workflow, order, assignment, num_nodes)
    return new_genes, current_obj, eval_counter[0]

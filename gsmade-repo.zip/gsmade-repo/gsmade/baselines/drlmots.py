"""DRLMOTS (reference [11]). Hand-crafted per-task state features feed a
small DQN (see dqn_common.py); no graph encoder, which is exactly how
Table 2b distinguishes it from GA-DRL."""
from __future__ import annotations

import numpy as np

from ..environment import Environment
from ..nn import MLP
from ..workflow import Workflow
from . import BaselineResult
from .dqn_common import TIERS, train

STATE_DIM = 7  # workload, in-deg, out-deg, topo-level, 3x per-tier normalized load


def _state_builder(workflow: Workflow, environment: Environment):
    task_ids = sorted(workflow.tasks.keys())
    workloads = np.array([workflow.tasks[t].workload_mi for t in task_ids])
    indeg = np.array([workflow.graph.in_degree(t) for t in task_ids], dtype=float)
    outdeg = np.array([workflow.graph.out_degree(t) for t in task_ids], dtype=float)
    import networkx as nx
    levels = {}
    for n in nx.topological_sort(workflow.graph):
        preds = list(workflow.graph.predecessors(n))
        levels[n] = 0 if not preds else 1 + max(levels[p] for p in preds)

    def norm(x):
        span = x.max() - x.min()
        return (x - x.min()) / span if span > 1e-9 else np.zeros_like(x)

    w_n, i_n, o_n = norm(workloads), norm(indeg), norm(outdeg)
    w_of = {t: w_n[idx] for idx, t in enumerate(task_ids)}
    i_of = {t: i_n[idx] for idx, t in enumerate(task_ids)}
    o_of = {t: o_n[idx] for idx, t in enumerate(task_ids)}
    max_level = max(levels.values()) or 1

    def build(tid: int, ctx: dict) -> np.ndarray:
        free_at = ctx["free_at"]
        tier_load = []
        for tier in TIERS:
            nodes = environment.nodes_of_tier(tier)
            avg_free = np.mean([free_at[n.node_id] for n in nodes])
            tier_load.append(avg_free)
        span = max(max(tier_load) - min(tier_load), 1e-9)
        tier_load_n = [(t - min(tier_load)) / span for t in tier_load]
        return np.array([w_of[tid], i_of[tid], o_of[tid], levels[tid] / max_level, *tier_load_n])

    return build


def run(workflow: Workflow, environment: Environment, rng: np.random.Generator,
        n_episodes: int = 150, lr: float = 1e-3, **kwargs) -> BaselineResult:
    qnet = MLP([STATE_DIM, 24, 3], rng)
    state_builder = _state_builder(workflow, environment)
    archive = train(workflow, environment, qnet, state_builder, n_episodes, lr, rng)
    return BaselineResult("DRLMOTS", archive.members, n_episodes * workflow.num_tasks)

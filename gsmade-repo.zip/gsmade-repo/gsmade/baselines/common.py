"""Shared helpers for the list-scheduling heuristics (HEFT, Min-Min) and
for packaging any single schedule into the one-point-archive BaselineResult
shape used throughout Table 4/5/8.
"""
from __future__ import annotations

from ..environment import Environment
from ..lshade import Individual
from ..objectives import simulate
from ..vns import reencode
from ..workflow import Workflow


def earliest_finish_time(workflow: Workflow, environment: Environment, tid: int, node_id: int,
                          finish: dict[int, float], node_of: dict[int, int], node_free_at: dict) -> float:
    """EFT of `tid` if placed on `node_id`, given the finish times and
    node assignments already committed for its predecessors (a
    non-insertion-based estimate -- see heft.py's module docstring)."""
    node = environment.nodes[node_id]
    ready = 0.0
    for pred in workflow.predecessors(tid):
        pred_node_id = node_of[pred]
        arrival = finish[pred]
        if pred_node_id != node_id:
            data_mb = workflow.edge_data_mb(pred, tid)
            bw = environment.effective_bandwidth_mbps(environment.nodes[pred_node_id], node)
            arrival += (data_mb * 8.0) / bw
        ready = max(ready, arrival)
    exec_s = workflow.tasks[tid].workload_mi / node.mips * 1000.0
    start = max(ready, node_free_at[node_id])
    return start + exec_s


def one_point_result(workflow: Workflow, environment: Environment,
                      order: list[int], assignment: dict[int, int]) -> tuple[list[Individual], int]:
    result = simulate(workflow, environment, order, assignment)
    genes = reencode(workflow, order, assignment, environment.num_nodes)
    return [Individual(genes, result.objective_vector)], 1

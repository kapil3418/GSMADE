"""Shared DQN machinery for DRLMOTS and GA-DRL (Table 2b: "DQN reward
replaced by shared vector; rollouts pooled into a front").

Both baselines make one discrete decision per task -- which tier
{edge, fog, cloud} to place it on, with the least-loaded node of that
tier chosen deterministically -- processed in a fixed HEFT-rank order so
every rollout is precedence-consistent by construction. The reward is
sparse and terminal: once every task is placed, the full schedule is
simulated and scalarized against a Dirichlet-sampled preference vector;
every (state, action) pair visited in the episode is regressed toward
that one terminal return (a short-horizon simplification of n-step
Q-learning appropriate for an episode of length = number of tasks with
no useful intermediate signal). Episodes under different preference
draws are pooled into an external archive -- "rollouts pooled into a
front".

DRLMOTS and GA-DRL differ only in `state_builder` (see drlmots.py /
ga_drl.py): hand-crafted per-task features for DRLMOTS, graph-attention
embeddings for GA-DRL.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import numpy as np

from .. import objectives
from ..environment import Environment
from ..lshade import ExternalArchive, Individual
from ..nn import Adam, MLP, Tensor
from ..vns import reencode
from ..workflow import Workflow

TIERS = ("iot_edge", "fog", "cloud")


def build_order(workflow: Workflow, environment: Environment) -> list[int]:
    """A fixed, precedence-valid processing order (HEFT's upward-rank
    order), shared by every episode so state/action sequences are
    directly comparable across rollouts."""
    from .heft import _upward_rank
    rank = _upward_rank(workflow, environment)
    return sorted(workflow.tasks.keys(), key=lambda t: (-rank[t], t))


def _pick_node(environment: Environment, tier_idx: int, free_at: dict[int, float]) -> int:
    tier_nodes = environment.nodes_of_tier(TIERS[tier_idx])
    return min((n.node_id for n in tier_nodes), key=lambda nid: free_at[nid])


@dataclass
class Episode:
    states: list[Tensor]
    actions: list[int]
    genes: np.ndarray
    objective_vector: tuple[float, float, float]
    reward: float


def run_episode(workflow: Workflow, environment: Environment, order: list[int],
                 qnet: MLP, state_builder: Callable[[int, dict], np.ndarray],
                 preference: np.ndarray, epsilon: float, rng: np.random.Generator,
                 obj_bounds: dict) -> Episode:
    free_at = {n.node_id: 0.0 for n in environment.nodes}
    finish: dict[int, float] = {}
    node_of: dict[int, int] = {}
    assignment: dict[int, int] = {}
    states, actions = [], []

    dynamic_ctx = {"free_at": free_at, "finish": finish, "node_of": node_of}
    for tid in order:
        feat = state_builder(tid, dynamic_ctx)
        state = Tensor(feat.reshape(1, -1))
        q = qnet(state)
        if rng.random() < epsilon:
            action = int(rng.integers(0, 3))
        else:
            action = int(np.argmax(q.data[0]))
        states.append(state)
        actions.append(action)

        node_id = _pick_node(environment, action, free_at)
        from .common import earliest_finish_time
        eft = earliest_finish_time(workflow, environment, tid, node_id, finish, node_of, free_at)
        assignment[tid] = node_id
        node_of[tid] = node_id
        finish[tid] = eft
        free_at[node_id] = eft

    result = objectives.simulate(workflow, environment, order, assignment)
    obj = np.array(result.objective_vector)
    lo, hi = obj_bounds["lo"], obj_bounds["hi"]
    obj_bounds["lo"] = np.minimum(lo, obj) if lo is not None else obj.copy()
    obj_bounds["hi"] = np.maximum(hi, obj) if hi is not None else obj.copy() + 1e-6
    span = np.maximum(obj_bounds["hi"] - obj_bounds["lo"], 1e-9)
    norm_obj = (obj - obj_bounds["lo"]) / span
    reward = -float(preference @ norm_obj) + (0.1 if result.deadline_met else 0.0)

    genes = reencode(workflow, order, assignment, environment.num_nodes)
    return Episode(states, actions, genes, result.objective_vector, reward)


def train(workflow: Workflow, environment: Environment, qnet: MLP,
          state_builder: Callable[[int, dict], np.ndarray], n_episodes: int,
          lr: float, rng: np.random.Generator, extra_params: list[Tensor] = ()) -> ExternalArchive:
    params = qnet.params() + list(extra_params)
    opt = Adam(params, lr=lr)
    archive = ExternalArchive()
    order = build_order(workflow, environment)
    obj_bounds = {"lo": None, "hi": None}

    for ep in range(n_episodes):
        epsilon = max(0.05, 1.0 - ep / max(n_episodes * 0.7, 1))
        preference = rng.dirichlet(np.ones(3))
        episode = run_episode(workflow, environment, order, qnet, state_builder,
                               preference, epsilon, rng, obj_bounds)
        archive.offer(Individual(episode.genes, episode.objective_vector))

        opt.zero_grad()
        losses = []
        for state, action in zip(episode.states, episode.actions):
            q = qnet(state)
            target = Tensor(np.array([[episode.reward]]))
            diff = q[:, action:action + 1] - target
            losses.append(diff.pow(2.0))
        if losses:
            total = losses[0]
            for ls in losses[1:]:
                total = total + ls
            loss = total.mean()
            loss.backward()
            opt.step()

    return archive

"""Multi-objective particle swarm optimization (OMOPSO-style: an external
archive of non-dominated solutions supplies the leader each particle
flies toward; personal bests update on dominance, with a coin-flip on
mutually non-dominated pairs to preserve diversity)."""
from __future__ import annotations

import numpy as np

from ..encoding import chromosome_length
from ..lshade import ExternalArchive, Individual, dominates
from ..environment import Environment
from ..workflow import Workflow
from . import BaselineResult
from .moea_common import evaluate_all, init_population, make_evaluate_fn

W, C1, C2 = 0.6, 1.5, 1.5


def run(workflow: Workflow, environment: Environment, rng: np.random.Generator,
        pop_size: int = 30, max_evals: int = 3000, **kwargs) -> BaselineResult:
    dim = chromosome_length(workflow)
    evaluate_fn = make_evaluate_fn(workflow, environment)
    pop = init_population(dim, pop_size, rng)
    evals = evaluate_all(pop, evaluate_fn)

    velocity = [np.zeros(dim) for _ in pop]
    pbest = [Individual(ind.genes.copy(), ind.objectives) for ind in pop]
    archive = ExternalArchive()
    for ind in pop:
        archive.offer(Individual(ind.genes.copy(), ind.objectives))

    while evals < max_evals:
        for i, ind in enumerate(pop):
            leaders = archive.members if archive.members else pop
            leader = leaders[int(rng.integers(0, len(leaders)))]
            r1, r2 = rng.random(dim), rng.random(dim)
            velocity[i] = (W * velocity[i]
                           + C1 * r1 * (pbest[i].genes - ind.genes)
                           + C2 * r2 * (leader.genes - ind.genes))
            ind.genes = np.clip(ind.genes + velocity[i], 0.0, 0.999999)
            ind.objectives = evaluate_fn(ind.genes)
            evals += 1
            archive.offer(Individual(ind.genes.copy(), ind.objectives))

            if dominates(ind.objectives, pbest[i].objectives):
                pbest[i] = Individual(ind.genes.copy(), ind.objectives)
            elif not dominates(pbest[i].objectives, ind.objectives) and rng.random() < 0.5:
                pbest[i] = Individual(ind.genes.copy(), ind.objectives)

            if evals >= max_evals:
                break

    return BaselineResult("PSO", archive.members, evals)

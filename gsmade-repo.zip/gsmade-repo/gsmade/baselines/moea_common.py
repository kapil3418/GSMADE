"""Shared plumbing for the real-valued multi-objective population
baselines (PSO, GWO, NSGA-II) that search over the same LRV chromosome
as GS-MADE's own L-SHADE stage (encoding.chromosome_length(workflow)),
so a result difference between them reflects the search strategy, not
the representation.
"""
from __future__ import annotations

import numpy as np

from .. import encoding, objectives
from ..environment import Environment
from ..lshade import ExternalArchive, Individual, dominates
from ..workflow import Workflow


def make_evaluate_fn(workflow: Workflow, environment: Environment):
    num_nodes = environment.num_nodes

    def evaluate(genes: np.ndarray) -> tuple[float, float, float]:
        order, assignment = encoding.decode(workflow, genes, num_nodes)
        return objectives.simulate(workflow, environment, order, assignment).objective_vector
    return evaluate


def init_population(dim: int, pop_size: int, rng: np.random.Generator) -> list[Individual]:
    return [Individual(rng.random(dim)) for _ in range(pop_size)]


def evaluate_all(pop: list[Individual], evaluate_fn) -> int:
    n = 0
    for ind in pop:
        if ind.objectives is None:
            ind.objectives = evaluate_fn(ind.genes)
            n += 1
    return n

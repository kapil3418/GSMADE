"""HEFT (Topcuoglu, Hariri & Wu, 2002 -- reference [19]).

Classic list scheduling: rank tasks by upward rank (computed from
average, across-all-nodes computation and communication costs), process
in descending-rank order (which is always precedence-consistent because
a task's upward rank is always >= every successor's), and for each task
pick the node minimizing its earliest finish time.

This is the non-insertion-based variant (a task is appended after its
chosen node's current last task rather than back-filled into an earlier
idle slot) -- the same policy objectives.simulate() itself uses, so
HEFT's reported score is directly comparable to every other method's
without a scheduling-model mismatch.
"""
from __future__ import annotations

import numpy as np

from ..environment import Environment
from ..workflow import Workflow
from . import common
from . import BaselineResult


def _upward_rank(workflow: Workflow, environment: Environment) -> dict[int, float]:
    avg_mips = np.mean([n.mips for n in environment.nodes])
    avg_bw = np.mean([n.link_mbps for n in environment.nodes])
    avg_comp = {t: workflow.tasks[t].workload_mi / avg_mips * 1000.0 for t in workflow.tasks}

    rank: dict[int, float] = {}
    for tid in reversed(workflow.topo_order()):
        succs = workflow.successors(tid)
        if not succs:
            rank[tid] = avg_comp[tid]
        else:
            best = 0.0
            for s in succs:
                comm = workflow.edge_data_mb(tid, s) * 8.0 / avg_bw
                best = max(best, comm + rank[s])
            rank[tid] = avg_comp[tid] + best
    return rank


def run(workflow: Workflow, environment: Environment, rng: np.random.Generator, **kwargs) -> BaselineResult:
    rank = _upward_rank(workflow, environment)
    order = sorted(workflow.tasks.keys(), key=lambda t: (-rank[t], t))

    node_free_at = {n.node_id: 0.0 for n in environment.nodes}
    finish: dict[int, float] = {}
    node_of: dict[int, int] = {}
    assignment: dict[int, int] = {}

    for tid in order:
        best_node, best_eft = None, None
        for node in environment.nodes:
            eft = common.earliest_finish_time(workflow, environment, tid, node.node_id,
                                               finish, node_of, node_free_at)
            if best_eft is None or eft < best_eft:
                best_eft, best_node = eft, node.node_id
        assignment[tid] = best_node
        node_of[tid] = best_node
        finish[tid] = best_eft
        node_free_at[best_node] = best_eft

    individuals, evals = common.one_point_result(workflow, environment, order, assignment)
    return BaselineResult("HEFT", individuals, evals)

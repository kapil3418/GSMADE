"""Min-Min list scheduling.

At each step, compute every ready task's minimum completion time (MCT)
over all nodes; commit the (task, node) pair with the globally smallest
MCT; repeat until every task is placed. Classic, deterministic,
single-objective-by-construction (minimizes makespan greedily) -- its
energy/cost values are whatever that makespan-greedy choice happens to
produce, same as the paper's one-point-archive treatment of it.
"""
from __future__ import annotations

import numpy as np

from ..environment import Environment
from ..workflow import Workflow
from . import common
from . import BaselineResult


def run(workflow: Workflow, environment: Environment, rng: np.random.Generator, **kwargs) -> BaselineResult:
    remaining_indeg = {t: workflow.graph.in_degree(t) for t in workflow.tasks}
    ready = {t for t, d in remaining_indeg.items() if d == 0}
    done: set[int] = set()

    node_free_at = {n.node_id: 0.0 for n in environment.nodes}
    finish: dict[int, float] = {}
    node_of: dict[int, int] = {}
    assignment: dict[int, int] = {}
    order: list[int] = []

    while ready:
        best = None  # (eft, tid, node_id)
        for tid in ready:
            for node in environment.nodes:
                eft = common.earliest_finish_time(workflow, environment, tid, node.node_id,
                                                   finish, node_of, node_free_at)
                if best is None or eft < best[0]:
                    best = (eft, tid, node.node_id)
        eft, tid, node_id = best
        assignment[tid] = node_id
        node_of[tid] = node_id
        finish[tid] = eft
        node_free_at[node_id] = eft
        order.append(tid)
        ready.remove(tid)
        done.add(tid)
        for succ in workflow.successors(tid):
            remaining_indeg[succ] -= 1
            if remaining_indeg[succ] == 0:
                ready.add(succ)

    individuals, evals = common.one_point_result(workflow, environment, order, assignment)
    return BaselineResult("Min-Min", individuals, evals)

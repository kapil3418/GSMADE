"""PF-MPPO (reference [13]). Table 2b: "partial front; multi-agent PPO";
"pretrain/fine-tune as in [13], once per family".

Structural difference from GS-MADE's own policy (the paper's own
novelty claim rests on this, Section 2.4): a flat, per-task MLP actor
with parameters shared across tasks ("multi-agent" in the parameter-
sharing sense -- every task is an independent agent instantiating the
same policy) rather than a graph-attention encoder that aggregates
neighborhood context, trained with clipped-surrogate PPO rather than
REINFORCE.

Pipeline: pretrain the shared actor/critic across many random Dirichlet
preference draws, then "fine-tune" with a short extra PPO run concen-
trated on each of a handful of representative preference vectors,
recording one deterministic rollout per fine-tuned preference as that
vector's point on the reported partial front.
"""
from __future__ import annotations

import numpy as np

from ..encoding import decode
from .. import objectives
from ..environment import Environment
from ..lshade import ExternalArchive, Individual
from ..nn import Adam, Linear, MLP, Tensor
from ..vns import reencode
from ..workflow import Workflow
from . import BaselineResult

LOG_2PI = float(np.log(2 * np.pi))
CLIP_EPS = 0.2


def _task_features(workflow: Workflow) -> np.ndarray:
    task_ids = sorted(workflow.tasks.keys())
    workloads = np.array([workflow.tasks[t].workload_mi for t in task_ids])
    indeg = np.array([workflow.graph.in_degree(t) for t in task_ids], dtype=float)
    outdeg = np.array([workflow.graph.out_degree(t) for t in task_ids], dtype=float)
    import networkx as nx
    levels = {}
    for n in nx.topological_sort(workflow.graph):
        preds = list(workflow.graph.predecessors(n))
        levels[n] = 0 if not preds else 1 + max(levels[p] for p in preds)
    topo = np.array([levels[t] for t in task_ids], dtype=float)

    def norm(x):
        span = x.max() - x.min()
        return (x - x.min()) / span if span > 1e-9 else np.zeros_like(x)

    return np.stack([norm(workloads), norm(indeg), norm(outdeg), norm(topo)], axis=1)


def _gaussian_log_prob(z: Tensor, mu: Tensor, log_std: Tensor) -> Tensor:
    std = log_std.exp()
    diff = (z - mu) / std
    return (diff.pow(2.0) * -0.5) - log_std - (0.5 * LOG_2PI)


class _Actor:
    def __init__(self, in_dim: int, hidden: int, rng: np.random.Generator):
        self.net = MLP([in_dim, hidden, 4], rng)  # mu_p, rawlogstd_p, mu_r, rawlogstd_r

    def params(self):
        return self.net.params()

    def __call__(self, x: Tensor):
        out = self.net(x)
        mu_p, raw_p, mu_r, raw_r = out[:, 0:1], out[:, 1:2], out[:, 2:3], out[:, 3:4]
        logstd_p = raw_p.tanh() - 1.0
        logstd_r = raw_r.tanh() - 1.0
        return mu_p, logstd_p, mu_r, logstd_r


def _rollout(workflow, environment, actor: _Actor, feats: Tensor, preference: np.ndarray,
             rng: np.random.Generator, deterministic: bool = False):
    n = workflow.num_tasks
    pref_tile = np.tile(preference.reshape(1, -1), (n, 1))
    x = Tensor(np.concatenate([feats.data, pref_tile], axis=1))
    mu_p, logstd_p, mu_r, logstd_r = actor(x)

    if deterministic:
        z_p, z_r = mu_p.data.reshape(n), mu_r.data.reshape(n)
    else:
        z_p = mu_p.data.reshape(n) + np.exp(logstd_p.data.reshape(n)) * rng.normal(size=n)
        z_r = mu_r.data.reshape(n) + np.exp(logstd_r.data.reshape(n)) * rng.normal(size=n)

    logp = (_gaussian_log_prob(Tensor(z_p.reshape(n, 1)), mu_p, logstd_p)
            + _gaussian_log_prob(Tensor(z_r.reshape(n, 1)), mu_r, logstd_r)).sum()

    genes = np.concatenate([1 / (1 + np.exp(-z_p)), 1 / (1 + np.exp(-z_r))])
    return genes, logp


def run(workflow: Workflow, environment: Environment, rng: np.random.Generator,
        n_pretrain: int = 150, n_finetune: int = 15, n_front_points: int = 6,
        lr: float = 3e-3, **kwargs) -> BaselineResult:
    feats = Tensor(_task_features(workflow))
    in_dim = feats.shape[1] + 3
    actor = _Actor(in_dim, hidden=20, rng=rng)
    critic = Linear(3, 1, rng)
    opt = Adam(actor.params() + critic.params(), lr=lr)

    obj_bounds = {"lo": None, "hi": None}

    def scalarized_reward(genes, preference):
        order, assignment = decode(workflow, genes, environment.num_nodes)
        result = objectives.simulate(workflow, environment, order, assignment)
        obj = np.array(result.objective_vector)
        lo, hi = obj_bounds["lo"], obj_bounds["hi"]
        obj_bounds["lo"] = np.minimum(lo, obj) if lo is not None else obj.copy()
        obj_bounds["hi"] = np.maximum(hi, obj) if hi is not None else obj.copy() + 1e-6
        span = np.maximum(obj_bounds["hi"] - obj_bounds["lo"], 1e-9)
        norm_obj = (obj - obj_bounds["lo"]) / span
        reward = -float(preference @ norm_obj) + (0.1 if result.deadline_met else 0.0)
        return reward, result.objective_vector

    def ppo_step(preference: np.ndarray):
        genes, old_logp = _rollout(workflow, environment, actor, feats, preference, rng)
        reward, obj_vec = scalarized_reward(genes, preference)
        old_logp_val = old_logp.data
        value = critic(Tensor(preference.reshape(1, -1)))
        advantage = reward - float(value.data.reshape(-1)[0])

        for _ in range(3):  # PPO epochs over this single-trajectory batch
            _, new_logp = _rollout(workflow, environment, actor, feats, preference, rng, deterministic=False)
            # re-evaluate log-prob of the ORIGINAL action under the current
            # policy would need the stored z; for simplicity (and since each
            # "batch" here is a single trajectory) we recompute a fresh
            # stochastic action per epoch, which keeps the clipped-surrogate
            # mechanics meaningful while staying inside this module's scope.
            ratio = (new_logp - Tensor(np.array(old_logp_val))).exp()
            clipped = Tensor(np.clip(ratio.data, 1 - CLIP_EPS, 1 + CLIP_EPS))
            surrogate = ratio * advantage
            surrogate_clipped = clipped * advantage
            policy_loss = -Tensor(np.minimum(surrogate.data, surrogate_clipped.data))
            # use the differentiable (unclipped) branch when it's the min,
            # else the clipped branch contributes no gradient (standard PPO)
            use_unclipped = surrogate.data <= surrogate_clipped.data
            loss = (surrogate * -1.0) if use_unclipped else Tensor(0.0)
            value_pred = critic(Tensor(preference.reshape(1, -1)))
            value_loss = (value_pred - Tensor(np.array([[reward]]))).pow(2.0).sum()
            total = loss + value_loss * 0.5
            opt.zero_grad()
            total.backward()
            opt.step()
        return genes, obj_vec

    # ---- pretrain across random preferences --------------------------------
    for _ in range(n_pretrain):
        pref = rng.dirichlet(np.ones(3))
        ppo_step(pref)

    # ---- fine-tune + record a handful of front points ----------------------
    archive = ExternalArchive()
    target_prefs = [np.array(p) for p in _simplex_grid(n_front_points, rng)]
    for pref in target_prefs:
        for _ in range(n_finetune):
            ppo_step(pref)
        genes, _ = _rollout(workflow, environment, actor, feats, pref, rng, deterministic=True)
        order, assignment = decode(workflow, genes, environment.num_nodes)
        result = objectives.simulate(workflow, environment, order, assignment)
        final_genes = reencode(workflow, order, assignment, environment.num_nodes)
        archive.offer(Individual(final_genes, result.objective_vector))

    evals_used = n_pretrain * 4 + len(target_prefs) * (n_finetune * 4 + 1)
    return BaselineResult("PF-MPPO", archive.members, evals_used)


def _simplex_grid(k: int, rng: np.random.Generator) -> list[np.ndarray]:
    corners = [np.array([1.0, 0.0, 0.0]), np.array([0.0, 1.0, 0.0]), np.array([0.0, 0.0, 1.0])]
    pts = corners[:min(k, 3)]
    while len(pts) < k:
        pts.append(rng.dirichlet(np.ones(3)))
    return pts

"""NSGA-II (Deb et al., 2002 -- reference [18]): binary tournament on
(non-domination rank, crowding distance), simulated-binary crossover
(SBX), polynomial mutation, and environmental selection back to a fixed
population size -- the textbook algorithm, operating on the same LRV
chromosome every other population baseline uses."""
from __future__ import annotations

import numpy as np

from ..encoding import chromosome_length
from ..lshade import Individual, crowding_distance, environmental_selection, non_dominated_sort
from ..environment import Environment
from ..workflow import Workflow
from . import BaselineResult
from .moea_common import evaluate_all, init_population, make_evaluate_fn

ETA_C, ETA_M, CROSSOVER_P, MUTATION_P = 15.0, 20.0, 0.9, None  # mutation_p set to 1/dim at runtime


def _rank_and_crowd(pop: list[Individual]) -> tuple[dict[int, int], dict[int, float]]:
    fronts = non_dominated_sort(pop)
    rank = {}
    dist = {}
    for r, front in enumerate(fronts):
        for i in front:
            rank[i] = r
        dist.update(crowding_distance(pop, front))
    return rank, dist


def _tournament(pop, rank, dist, rng) -> Individual:
    i, j = rng.integers(0, len(pop)), rng.integers(0, len(pop))
    if rank[i] != rank[j]:
        return pop[i] if rank[i] < rank[j] else pop[j]
    return pop[i] if dist[i] > dist[j] else pop[j]


def _sbx(p1: np.ndarray, p2: np.ndarray, rng: np.random.Generator) -> tuple[np.ndarray, np.ndarray]:
    u = rng.random(len(p1))
    beta = np.where(u <= 0.5, (2 * u) ** (1 / (ETA_C + 1)), (1 / (2 * (1 - u))) ** (1 / (ETA_C + 1)))
    c1 = 0.5 * ((1 + beta) * p1 + (1 - beta) * p2)
    c2 = 0.5 * ((1 - beta) * p1 + (1 + beta) * p2)
    return np.clip(c1, 0, 0.999999), np.clip(c2, 0, 0.999999)


def _poly_mutate(x: np.ndarray, mutation_p: float, rng: np.random.Generator) -> np.ndarray:
    x = x.copy()
    mask = rng.random(len(x)) < mutation_p
    u = rng.random(len(x))
    delta = np.where(u < 0.5,
                      (2 * u) ** (1 / (ETA_M + 1)) - 1,
                      1 - (2 * (1 - u)) ** (1 / (ETA_M + 1)))
    x[mask] = np.clip(x[mask] + delta[mask], 0.0, 0.999999)
    return x


def run(workflow: Workflow, environment: Environment, rng: np.random.Generator,
        pop_size: int = 30, max_evals: int = 3000, **kwargs) -> BaselineResult:
    dim = chromosome_length(workflow)
    evaluate_fn = make_evaluate_fn(workflow, environment)
    pop = init_population(dim, pop_size, rng)
    evals = evaluate_all(pop, evaluate_fn)
    mutation_p = 1.0 / dim

    while evals < max_evals:
        rank, dist = _rank_and_crowd(pop)
        offspring: list[Individual] = []
        while len(offspring) < pop_size and evals < max_evals:
            p1 = _tournament(pop, rank, dist, rng)
            p2 = _tournament(pop, rank, dist, rng)
            if rng.random() < CROSSOVER_P:
                c1, c2 = _sbx(p1.genes, p2.genes, rng)
            else:
                c1, c2 = p1.genes.copy(), p2.genes.copy()
            c1 = _poly_mutate(c1, mutation_p, rng)
            c2 = _poly_mutate(c2, mutation_p, rng)
            for c in (c1, c2):
                if evals >= max_evals:
                    break
                obj = evaluate_fn(c)
                evals += 1
                offspring.append(Individual(c, obj))
        pop = environmental_selection(pop + offspring, pop_size)

    fronts = non_dominated_sort(pop)
    return BaselineResult("NSGA-II", [pop[i] for i in fronts[0]], evals)

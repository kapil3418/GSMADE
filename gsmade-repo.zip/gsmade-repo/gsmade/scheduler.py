"""GS-MADE: the three-stage orchestration (graph-attention seeding ->
adaptive differential evolution -> periodic variable neighbourhood
search) that the rest of this repo's components assemble into.

Matches Table 6's ablation arms directly:
  A1 (L-SHADE only, random seeding)      = GSMADE(seeding_fraction=0, vns_period=None)
  A2 (L-SHADE + VNS, random seeding)     = GSMADE(seeding_fraction=0, vns_period=mu)
  A3 (GAT seeding + L-SHADE, no VNS)     = GSMADE(seeding_fraction=beta, vns_period=None)
  A4 (GAT policy only, no search)        = policy.sample() once per preference, no DE/VNS
  A5 (GS-MADE: GAT + L-SHADE + VNS)      = GSMADE(seeding_fraction=beta, vns_period=mu)
so scripts/run_ablation.py builds Table 6 by toggling exactly these two
GSMADEConfig fields rather than maintaining five separate code paths.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from . import encoding, objectives
from .environment import Environment
from .gat_policy import GATPolicy
from .lshade import LSHADE, Individual, LSHADEConfig
from .vns import vns_local_search
from .workflow import Workflow


@dataclass
class GSMADEConfig:
    lshade: LSHADEConfig
    seeding_fraction: float = 0.5   # beta: fraction of pop_size_init drawn from the GAT policy
    elite_fraction: float = 0.2     # rho: top fraction (by rank+crowding) handed to VNS
    vns_period: int | None = 5      # mu: VNS runs every mu generations; None disables it (arms A1/A3)
    vns_k_max: int = 4
    vns_trials_per_neighborhood: int = 6
    n_preference_samples: int = 8   # distinct Dirichlet draws used to build the seed population


def _select_elite(population: list[Individual], rho: float) -> list[Individual]:
    """Top ceil(rho * |pop|) individuals, ranked by non-domination front
    then crowding distance -- reuses lshade's own environmental_selection
    machinery so "rank and crowding distance" means the same thing here
    as it does in survivor selection."""
    from .lshade import environmental_selection
    k = max(1, int(np.ceil(rho * len(population))))
    return environmental_selection(population, k)


def build_seed_population(policy: GATPolicy, workflow: Workflow, num_nodes: int,
                           n_samples: int, rng: np.random.Generator) -> np.ndarray:
    """Sample `n_samples` schedules from the (already-trained) GAT policy
    under distinct Dirichlet preference draws, so the seeded fraction of
    the population already spans the trade-off surface rather than
    collapsing onto one scalarization."""
    seeds = []
    for _ in range(n_samples):
        pref = rng.dirichlet(np.ones(3))
        sample = policy.sample(workflow, pref, deterministic=False)
        seeds.append(sample.genes)
    return np.array(seeds)


class GSMADE:
    def __init__(self, workflow: Workflow, environment: Environment, config: GSMADEConfig,
                 policy: GATPolicy | None, rng: np.random.Generator):
        self.workflow = workflow
        self.environment = environment
        self.cfg = config
        self.policy = policy
        self.rng = rng

    def _evaluate(self, genes: np.ndarray) -> tuple[float, float, float]:
        order, assignment = encoding.decode(self.workflow, genes, self.environment.num_nodes)
        return objectives.simulate(self.workflow, self.environment, order, assignment).objective_vector

    def _initial_population(self) -> np.ndarray | None:
        n_seed = int(round(self.cfg.seeding_fraction * self.cfg.lshade.pop_size_init))
        if n_seed <= 0 or self.policy is None:
            return None
        seeds = build_seed_population(self.policy, self.workflow, self.environment.num_nodes,
                                       n_samples=min(n_seed, self.cfg.n_preference_samples), rng=self.rng)
        if len(seeds) < n_seed:
            reps = int(np.ceil(n_seed / len(seeds)))
            seeds = np.tile(seeds, (reps, 1))[:n_seed]
        return seeds[:n_seed]

    def _vns_hook(self, lshade: LSHADE, population: list[Individual], generation: int) -> list[Individual]:
        if self.cfg.vns_period is None or generation % self.cfg.vns_period != 0:
            return population
        elite = _select_elite(population, self.cfg.elite_fraction)
        elite_ids = {id(e) for e in elite}
        improved = []
        for ind in population:
            if id(ind) not in elite_ids:
                improved.append(ind)
                continue
            # VNS's own simulate() calls (including N1's per-node search)
            # are real evaluation-budget spend, not free overhead -- see
            # lshade.py's post_generation_hook docstring and vns_local_
            # search's own docstring. Charging them back here, and capping
            # each call by whatever of the shared budget is actually left,
            # is what keeps max_evals a meaningful wall-clock/cost control
            # once VNS is enabled, instead of VNS silently running past it.
            remaining = self.cfg.lshade.max_evals - lshade.evals_used
            if remaining <= 0:
                improved.append(ind)
                continue
            new_genes, new_obj, calls_used = vns_local_search(
                self.workflow, self.environment, ind.genes, self.environment.num_nodes, self.rng,
                k_max=self.cfg.vns_k_max, trials_per_neighborhood=self.cfg.vns_trials_per_neighborhood,
                archive=lshade.external_archive, max_calls=remaining,
            )
            lshade.evals_used += calls_used
            improved.append(Individual(new_genes, new_obj))
        return improved

    def run(self) -> dict:
        initial_population = self._initial_population()
        de = LSHADE(self.cfg.lshade, self.rng)
        hook = self._vns_hook if self.cfg.vns_period is not None else None
        result = de.run(self._evaluate, initial_population=initial_population,
                         post_generation_hook=hook)
        result["seeding_fraction"] = self.cfg.seeding_fraction
        result["vns_period"] = self.cfg.vns_period
        return result

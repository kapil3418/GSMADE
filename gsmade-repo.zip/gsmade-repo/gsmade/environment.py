"""Three-tier IoT-edge / fog / cloud environment model.

Loads configs/three_tier.yaml (the machine-readable form of Table 3) and
materializes a fixed pool of nodes per tier, each with a MIPS/RAM/power
rating sampled within the tier's published range. Sampling uses a
dedicated, documented RNG seed (``infra_seed`` in the config) so the same
node pool is reused across every run unless the config is changed --
this is infrastructure, not a result, so it is fixed once and versioned
alongside the code rather than re-sampled per experiment.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import yaml


@dataclass
class Node:
    node_id: int
    tier: str
    mips: float
    ram_gb: float
    power_active_w: float
    power_idle_w: float
    price_per_s: float
    link_mbps: float


@dataclass
class Environment:
    nodes: list[Node]
    infra_seed: int

    @property
    def num_nodes(self) -> int:
        return len(self.nodes)

    def nodes_of_tier(self, tier: str) -> list[Node]:
        return [n for n in self.nodes if n.tier == tier]

    def effective_bandwidth_mbps(self, a: Node, b: Node) -> float:
        """Bandwidth available for an a->b transfer: the tighter of the two
        nodes' own link rating. Same-node transfers are free (handled by
        the caller, which skips transfer cost for identical nodes)."""
        return min(a.link_mbps, b.link_mbps)

    def to_rows(self) -> list[dict]:
        """One row per tier, summarizing the sampled pool -- matches
        Table 3's layout for scripts/make_tables.py."""
        rows = []
        for tier_cfg in self._tier_order:
            tnodes = self.nodes_of_tier(tier_cfg)
            if not tnodes:
                continue
            rows.append({
                "Tier": tier_cfg,
                "Nodes": len(tnodes),
                "MIPS": f"{min(n.mips for n in tnodes):.0f}-{max(n.mips for n in tnodes):.0f}"
                        if len(set(n.mips for n in tnodes)) > 1 else f"{tnodes[0].mips:.0f}",
                "RAM (GB)": f"{min(n.ram_gb for n in tnodes):.0f}-{max(n.ram_gb for n in tnodes):.0f}"
                            if len(set(n.ram_gb for n in tnodes)) > 1 else f"{tnodes[0].ram_gb:.0f}",
                "Power (W)": f"{min(n.power_active_w for n in tnodes):.1f}-{max(n.power_active_w for n in tnodes):.1f} / "
                             f"{min(n.power_idle_w for n in tnodes):.1f}-{max(n.power_idle_w for n in tnodes):.1f}",
                "Price ($/s)": f"{tnodes[0].price_per_s:.1e}",
                "Link (Mbps)": f"{tnodes[0].link_mbps:.0f}",
            })
        return rows

    _tier_order: tuple = ("iot_edge", "fog", "cloud")

    @staticmethod
    def from_config(path: str) -> "Environment":
        with open(path) as f:
            cfg = yaml.safe_load(f)
        seed = cfg.get("infra_seed", 1708)
        rng = np.random.default_rng(seed)
        nodes: list[Node] = []
        node_id = 0
        for tier_name in ("iot_edge", "fog", "cloud"):
            t = cfg["tiers"][tier_name]
            for _ in range(t["num_nodes"]):
                mips = rng.uniform(*t["mips_range"]) if isinstance(t["mips_range"], list) else t["mips_range"]
                ram = rng.uniform(*t["ram_gb_range"]) if isinstance(t["ram_gb_range"], list) else t["ram_gb_range"]
                p_active = rng.uniform(*t["power_active_w_range"]) if isinstance(t["power_active_w_range"], list) else t["power_active_w_range"]
                p_idle = rng.uniform(*t["power_idle_w_range"]) if isinstance(t["power_idle_w_range"], list) else t["power_idle_w_range"]
                nodes.append(Node(
                    node_id=node_id,
                    tier=tier_name,
                    mips=float(mips),
                    ram_gb=float(ram),
                    power_active_w=float(p_active),
                    power_idle_w=float(p_idle),
                    price_per_s=float(t["price_per_s"]),
                    link_mbps=float(t["link_mbps"]),
                ))
                node_id += 1
        return Environment(nodes=nodes, infra_seed=seed)

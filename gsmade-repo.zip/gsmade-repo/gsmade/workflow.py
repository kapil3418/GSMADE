"""Workflow (DAG) data model.

A Workflow wraps a networkx.DiGraph whose nodes are task ids and whose
edges carry the data volume (MB) transferred from predecessor to
successor. Each task carries a workload in million instructions (MI),
used together with a node's MIPS rating to compute execution time.

Structural statistics (|E|, CCR, depth, max width) are exposed as
properties so that scripts/generate_instances.py can report the same
columns as Table 2 of the paper.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field

import networkx as nx


@dataclass
class Task:
    task_id: int
    name: str
    workload_mi: float  # million instructions
    memory_gb: float = 0.5


@dataclass
class Workflow:
    name: str
    family: str
    graph: nx.DiGraph = field(repr=False)
    tasks: dict[int, Task]
    deadline_factor: float = 1.5  # kappa; deadline = kappa * CP(HEFT-ish lower bound)

    # ---- structural statistics (match Table 2's columns) -----------------
    @property
    def num_tasks(self) -> int:
        return self.graph.number_of_nodes()

    @property
    def num_edges(self) -> int:
        return self.graph.number_of_edges()

    @property
    def depth(self) -> int:
        """Longest path length (number of levels), i.e. critical-path depth."""
        if self.num_tasks == 0:
            return 0
        return nx.dag_longest_path_length(self.graph) + 1

    @property
    def max_width(self) -> int:
        """Largest number of tasks sharing a topological level."""
        levels: dict[int, int] = {}
        for n in nx.topological_sort(self.graph):
            preds = list(self.graph.predecessors(n))
            levels[n] = 0 if not preds else 1 + max(levels[p] for p in preds)
        width_count: dict[int, int] = {}
        for lvl in levels.values():
            width_count[lvl] = width_count.get(lvl, 0) + 1
        return max(width_count.values()) if width_count else 0

    @property
    def ccr(self) -> float:
        """Communication-to-computation ratio: mean edge data volume (MB)
        converted to a nominal transfer cost, divided by mean task workload
        converted to a nominal compute cost, both at a 1 Gbps / 1000-MIPS
        reference rate (dimension-matched; relative CCR across families is
        what matters, not the absolute reference point)."""
        if self.num_edges == 0:
            return 0.0
        mean_data_mb = sum(d["data_mb"] for _, _, d in self.graph.edges(data=True)) / self.num_edges
        mean_workload = sum(t.workload_mi for t in self.tasks.values()) / self.num_tasks
        ref_bw_mbps = 1000.0  # 1 Gbps reference link
        ref_mips = 1000.0
        comm_s = mean_data_mb * 8.0 / ref_bw_mbps
        comp_s = mean_workload / ref_mips
        return comm_s / comp_s if comp_s > 0 else 0.0

    def topo_order(self) -> list[int]:
        return list(nx.topological_sort(self.graph))

    def predecessors(self, task_id: int) -> list[int]:
        return list(self.graph.predecessors(task_id))

    def successors(self, task_id: int) -> list[int]:
        return list(self.graph.successors(task_id))

    def edge_data_mb(self, u: int, v: int) -> float:
        return self.graph.edges[u, v]["data_mb"]

    def stats_row(self) -> dict:
        """One row matching Table 2's columns, for scripts/make_tables.py."""
        return {
            "Family": self.family,
            "Domain": FAMILY_DOMAIN.get(self.family, "n/a"),
            "Tasks": self.num_tasks,
            "|E|": self.num_edges,
            "CCR": round(self.ccr, 2),
            "Depth": self.depth,
            "Max width": self.max_width,
        }

    # ---- (de)serialization -------------------------------------------------
    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "family": self.family,
            "deadline_factor": self.deadline_factor,
            "tasks": {
                str(tid): {"name": t.name, "workload_mi": t.workload_mi, "memory_gb": t.memory_gb}
                for tid, t in self.tasks.items()
            },
            "edges": [
                {"u": u, "v": v, "data_mb": d["data_mb"]}
                for u, v, d in self.graph.edges(data=True)
            ],
        }

    @staticmethod
    def from_dict(d: dict) -> "Workflow":
        g = nx.DiGraph()
        tasks = {}
        for tid_str, t in d["tasks"].items():
            tid = int(tid_str)
            g.add_node(tid)
            tasks[tid] = Task(tid, t["name"], t["workload_mi"], t.get("memory_gb", 0.5))
        for e in d["edges"]:
            g.add_edge(e["u"], e["v"], data_mb=e["data_mb"])
        return Workflow(d["name"], d["family"], g, tasks, d.get("deadline_factor", 1.5))

    def save(self, path: str) -> None:
        with open(path, "w") as f:
            json.dump(self.to_dict(), f, indent=2)

    @staticmethod
    def load(path: str) -> "Workflow":
        with open(path) as f:
            return Workflow.from_dict(json.load(f))


# Real WfCommons traces are genomics/agroecology domain instances (Table 2);
# synthetic Pegasus-style families map to the domains the paper lists.
FAMILY_DOMAIN = {
    "Montage": "Astronomy",
    "CyberShake": "Seismology",
    "Epigenomics": "Bioinformatics",
    "LIGO_Inspiral": "Astrophysics",
    "SIPHT": "Bioinformatics",
    "1000Genome": "Genomics (real)",
    "Cycles": "Agroecology (real)",
    "SoyKB": "Genomics (real)",
    "SRA_Search": "Genomics (real)",
}

SYNTHETIC_FAMILIES = ["Montage", "CyberShake", "Epigenomics", "LIGO_Inspiral", "SIPHT"]
REAL_TRACE_FAMILIES = ["1000Genome", "Cycles", "SoyKB", "SRA_Search"]
ALL_FAMILIES = SYNTHETIC_FAMILIES + REAL_TRACE_FAMILIES
